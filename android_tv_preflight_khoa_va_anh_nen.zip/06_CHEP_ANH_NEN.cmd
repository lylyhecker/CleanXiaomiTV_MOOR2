@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHEP_ANH_NEN.ps1"
if errorlevel 1 echo [ERROR] Wallpaper transfer failed.
pause
