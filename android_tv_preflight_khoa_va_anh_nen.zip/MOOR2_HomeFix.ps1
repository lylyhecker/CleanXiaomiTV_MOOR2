﻿param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('status','switch','restore')]
    [string]$Action,
    [string]$Serial = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$customPkg = 'com.majnioui.cleanxiaomitv'
$customActivity = 'com.majnioui.cleanxiaomitv/com.gathin.tvhome.MainActivity'
$stockPkg = 'com.google.android.apps.tv.launcherx'
$stockActivity = 'com.google.android.apps.tv.launcherx/com.google.android.apps.tv.launcherx.home.HomeActivity'
$setupPkg = 'com.google.android.tungsten.setupwraith'
$stateDir = Join-Path $root 'state'
$statePath = Join-Path $stateDir 'last_home_fix.json'
$latestBackup = Join-Path $stateDir 'home_before.txt'

function Fail([string]$message) { throw $message }
function Find-Adb {
    $options = @(
        (Join-Path $root 'adb.exe'),
        (Join-Path $root 'platform-tools\adb.exe'),
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')
    )
    foreach($path in $options) { if (Test-Path -LiteralPath $path -PathType Leaf) { return $path } }
    $command = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    Fail 'Cannot find adb.exe. Install Android SDK Platform-Tools or add adb.exe to PATH.'
}
function Connect-Tv {
    $script:adb = Find-Adb
    $result = @(& $script:adb devices)
    $online = @($result | ForEach-Object { if ($_ -match '^([^\s]+)\s+device\s*$') { $Matches[1] } })
    if ($Serial) {
        if ($online -notcontains $Serial) { Fail ('ADB serial not online: ' + $Serial) }
        $script:tv = $Serial
    } elseif ($online.Count -eq 1) {
        $script:tv = $online[0]
    } elseif ($online.Count -eq 0) {
        Fail 'No ADB TV is online. Run adb connect YOUR_TV_IP:5555 in CMD, then retry.'
    } else {
        Fail ('Multiple ADB devices (' + ($online -join ', ') + '). Pass -Serial YOUR_TV_IP:5555.')
    }
    $model = (Run-Tv -params @('getprop','ro.product.model')).Trim()
    $device = (Run-Tv -params @('getprop','ro.product.device')).Trim()
    $android = (Run-Tv -params @('getprop','ro.build.version.release')).Trim()
    $fingerprint = (Run-Tv -params @('getprop','ro.build.fingerprint')).Trim()
    Write-Host ('Connected: ' + $script:tv + ' / ' + $model + ' / Android ' + $android) -ForegroundColor Cyan
    Write-Host ('Firmware: ' + $fingerprint)
    if ($model -ne 'MiTV-MOOR2' -or $device -ne 'venom' -or $android -ne '11') {
        Fail 'Wrong TV model or Android version. This tool only supports MiTV-MOOR2 (venom), Android 11.'
    }
    if ($Action -eq 'switch' -and $fingerprint -notmatch '/1879:') {
        Fail 'Firmware is not the previously inspected build 1879. No launcher packages will be disabled.'
    }
}
function Run-Tv([string[]]$params) {
    # Capture ADB's stdout/stderr as process data rather than native PowerShell errors.
    # Android's `am start` can legitimately emit a warning when the app is already foreground.
    $tokens = @('-s', $script:tv, 'shell') + @($params)
    $quoted = @()
    foreach ($token in $tokens) {
        $value = [string]$token
        if ($value -match '["\r\n]') { Fail 'Invalid ADB argument contains a quote or newline.' }
        $quoted += ('"' + $value + '"')
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:adb
    $psi.Arguments = ($quoted -join ' ')
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    try {
        [void]$process.Start()
        # Read both redirected pipes concurrently, preventing a possible blocked subprocess.
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(60000)) {
            try { $process.Kill() } catch { }
            Fail ('ADB command timed out: ' + ($params -join ' '))
        }
        $stdout = $stdoutTask.GetAwaiter().GetResult().Trim()
        $stderr = $stderrTask.GetAwaiter().GetResult().Trim()
        if ($process.ExitCode -ne 0) {
            Fail ('ADB command failed (exit ' + $process.ExitCode + '): ' + ($params -join ' ') + "`n" + $stdout + "`n" + $stderr)
        }
        if ($stderr) {
            if ($stderr -match 'Warning:\s*Activity not started, intent has been delivered to currently running top-most instance') {
                Write-Host '[INFO] CleanXiaomiTV is already running. Android reused its activity.' -ForegroundColor DarkCyan
            } else {
                Write-Warning ('ADB reported: ' + $stderr)
            }
        }
        if ($stdout -match 'Warning:\s*Activity not started, intent has been delivered to currently running top-most instance') {
            Write-Host '[INFO] Android delivered the launch intent to the app already in foreground.' -ForegroundColor DarkCyan
        }
        return $stdout
    } finally {
        $process.Dispose()
    }
}
function DisabledSet {
    $text = Run-Tv -params @('pm','list','packages','-d')
    $names = @($text -split "`n" | ForEach-Object { $_.Trim() -replace '^package:', '' } | Where-Object { $_ })
    return $names
}
function Is-Disabled([string]$pkg) {
    $disabled = @(DisabledSet)
    return ($disabled -contains $pkg)
}
function Installed([string]$pkg) {
    $value = Run-Tv -params @('pm','path',$pkg)
    return ($value -match 'package:')
}
function Current-Home {
    return Run-Tv -params @('cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
}
function Current-Focus {
    $raw = Run-Tv -params @('dumpsys','activity','activities')
    $lines = @($raw -split "`r?`n" | Where-Object { $_ -match 'topResumedActivity|mFocusedApp|mResumedActivity' })
    $focused = @($lines | Where-Object { $_ -match 'mFocusedApp' })
    if ($focused.Count -gt 0) { return $focused[-1].Trim() }
    $top = @($lines | Where-Object { $_ -match 'topResumedActivity' })
    if ($top.Count -gt 0) { return $top[-1].Trim() }
    return ($lines -join "`n")
}
function Home-Key-Test {
    [void](Run-Tv -params @('input','keyevent','3'))
    Start-Sleep -Seconds 2
    return Current-Focus
}
function Disable-Pkg([string]$pkg) {
    Write-Host ('Disabling: ' + $pkg) -ForegroundColor Yellow
    $result = Run-Tv -params @('pm','disable-user','--user','0',$pkg)
    Write-Host $result
    if (-not (Is-Disabled $pkg)) { Fail ('Not disabled: ' + $pkg) }
}
function Enable-Pkg([string]$pkg) {
    if (Is-Disabled $pkg) {
        Write-Host ('Re-enabling: ' + $pkg) -ForegroundColor Yellow
        Write-Host (Run-Tv -params @('pm','enable','--user','0',$pkg))
    }
}
function Set-Home([string]$activity) {
    Write-Host (Run-Tv -params @('cmd','package','set-home-activity','--user','0',$activity))
}
function Snapshot([string]$name) {
    New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
    $content = @(
        ('Time: ' + (Get-Date -Format o)),
        ('Device: ' + $script:tv),
        ('Home: ' + (Current-Home)),
        ('Focus: ' + (Current-Focus)),
        ('Disabled: ' + ((@(DisabledSet)) -join ', ')),
        ('WiFi creator lines: ' + (Get-WifiCreators)),
        ('Home candidates: ' + (Run-Tv -params @('cmd','package','query-activities','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')))
    ) -join "`r`n`r`n"
    $path = Join-Path $stateDir ($name + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
    [System.IO.File]::WriteAllText($path,$content,[System.Text.Encoding]::UTF8)
    Write-Host ('Snapshot: ' + $path)
}
function Get-WifiCreators {
    $wifi = Run-Tv -params @('dumpsys','wifi')
    $matchesFound = @([regex]::Matches($wifi,'cname=[^\s,}\]]+') | ForEach-Object { $_.Value } | Select-Object -Unique)
    return ($matchesFound -join "`n")
}
function Get-AdbLanInterface {
    # The ADB TCP target must be bound directly to an Ethernet network interface.
    # A saved Wi-Fi entry alone does not prove that current ADB uses Wi-Fi.
    if ($script:tv -match '^([0-9]{1,3}(?:\.[0-9]{1,3}){3}):([0-9]+)$') {
        $targetIp = $Matches[1]
    } else {
        Fail 'ADB serial is not an IPv4 address with port. Cannot verify LAN connection; no packages will be disabled.'
    }
    $addresses = Run-Tv -params @('ip','-o','-4','addr','show')
    $interface = ''
    foreach ($line in ($addresses -split "`r?`n")) {
        if ($line -match '^\s*\d+:\s+([^\s:]+)\s+inet\s+([0-9.]+)/') {
            if ($Matches[2] -eq $targetIp) { $interface = $Matches[1]; break }
        }
    }
    Write-Host ('ADB target IP: ' + $targetIp)
    Write-Host ('Interface holding that IP: ' + $(if ($interface) { $interface } else { 'UNKNOWN' }))
    if (-not $interface) {
        Fail 'Cannot match ADB IP to a TV network interface. No system changes made.'
    }
    if ($interface -notmatch '^(eth[0-9]*|en[0-9A-Za-z._-]*)$') {
        Fail ('ADB is not on a recognized Ethernet interface (' + $interface + '). No system changes made.')
    }
    $connectivity = Run-Tv -params @('dumpsys','connectivity')
    if ($connectivity -notmatch '(?i)Transports:\s*ETHERNET(?:\W|$)') {
        Fail 'Android connectivity does not confirm an Ethernet transport. No system changes made.'
    }
    Write-Host 'Verified: the TV ADB IPv4 address is assigned to Ethernet and Android reports ETHERNET.' -ForegroundColor Green
    return $interface
}
function Check-WifiOwnership {
    if (Is-Disabled $setupPkg) { return }
    $names = Get-WifiCreators
    Write-Host 'Saved Wi-Fi creator identities (not active network):'
    Write-Host $names
    # The missing creator case remains conservative, even if Ethernet seems active.
    if (-not $names) {
        Fail 'Cannot determine ownership of saved Wi-Fi networks; leave setupwraith enabled. No changes made.'
    }
    if ($names -notmatch '(?i)setupwraith') { return }

    # Only bypass the saved Wi-Fi block when current ADB actually uses Ethernet.
    # A USB Ethernet adapter can lose power during debugging on some TV builds;
    # software cannot reliably distinguish that adapter from built-in RJ45.
    Write-Warning 'A saved Wi-Fi network belongs to setupwraith. It may be DELETED when that package is disabled, even if TV currently uses LAN.'
    $interface = Get-AdbLanInterface
    Write-Warning 'IMPORTANT: Ethernet over a USB adapter is NOT safe for this automated switch.'
    $lan = Read-Host 'Is the TV connected via its BUILT-IN RJ45 Ethernet port (NOT USB Ethernet)? Type RJ45 to confirm'
    if ($lan -cne 'RJ45') {
        Fail 'Cannot confirm built-in wired Ethernet. Stopped safely; no system packages disabled.'
    }
    $agree = Read-Host 'setupwraith may delete previously saved Wi-Fi networks. Type ACCEPT_WIFI_LOSS to continue'
    if ($agree -cne 'ACCEPT_WIFI_LOSS') {
        Fail 'Wi-Fi preservation selected. Stopped safely; no system packages disabled.'
    }
    Write-Host ('LAN safeguard accepted for interface ' + $interface + '. Continuing only after final SWITCH confirmation.') -ForegroundColor Yellow
}
function Is-Custom-Focused {
    $focus = Home-Key-Test
    Write-Host ('HOME focus result:' + "`n" + $focus)
    return ($focus -match [regex]::Escape($customPkg))
}
function Status {
    Connect-Tv
    Write-Host ('Custom launcher installed: ' + (Installed $customPkg))
    Write-Host ('Google TV launcher disabled: ' + (Is-Disabled $stockPkg))
    Write-Host ('Google setup wizard disabled: ' + (Is-Disabled $setupPkg))
    Write-Host 'Current HOME resolution:'
    Write-Host (Current-Home)
    Write-Host 'Current focused activity:'
    Write-Host (Current-Focus)
    Write-Host 'Saved Wi-Fi network creators (read-only):'
    Write-Host (Get-WifiCreators)
    Snapshot 'status'
    Write-Host 'No system settings were changed.' -ForegroundColor Green
}
function Invoke-HomeSwitch {
    Connect-Tv
    if (-not (Installed $customPkg)) { Fail 'CleanXiaomiTV app not found: run 02_CAI_THU.cmd first.' }
    if (-not (Installed $stockPkg)) { Fail 'Original Google TV launcher is missing; refuse to switch.' }
    Snapshot 'before_switch'
    $stockDisabledBefore = Is-Disabled $stockPkg
    $setupDisabledBefore = Is-Disabled $setupPkg
    Write-Host 'Launching CleanXiaomiTV (an already-running warning is normal)...'
    [void](Run-Tv -params @('am','start','-n',$customActivity))
    Start-Sleep -Seconds 2
    $manual = Current-Focus
    Write-Host ('Custom app after direct launch:' + "`n" + $manual)
    if ($manual -notmatch [regex]::Escape($customPkg)) {
        Fail 'Custom launcher did not reach foreground. No system packages changed.'
    }
    Set-Home $customActivity
    if (Is-Custom-Focused) {
        Write-Host 'SUCCESS: Custom launcher already handles HOME. No system packages were disabled.' -ForegroundColor Green
        return
    }
    Write-Warning 'Google TV still takes HOME. This firmware often requires disabling Google TV Launcher and setupwraith.'
    Write-Warning 'Changing setupwraith may impact setup or saved Wi-Fi; check ownership first.'
    Check-WifiOwnership
    Write-Host 'Rollback available in 03_KHOI_PHUC_HOME.cmd and with adb shell pm enable.'
    Write-Host 'Only these TWO packages may be temporarily disabled: '
    Write-Host ('  ' + $setupPkg)
    Write-Host ('  ' + $stockPkg)
    $answer = Read-Host 'Type SWITCH to proceed (anything else cancels)'
    if ($answer -cne 'SWITCH') { Write-Host 'Cancelled; original Google TV home is untouched.'; return }
    $data = [ordered]@{
        before = (Get-Date -Format o)
        device = $script:tv
        stockDisabledBefore = $stockDisabledBefore
        setupDisabledBefore = $setupDisabledBefore
    }
    New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
    ($data | ConvertTo-Json) | Set-Content -LiteralPath $statePath -Encoding UTF8
    try {
        # Disable setupwraith FIRST, with stock Home still present: avoids rebooting into RecoveryActivity.
        if (-not $setupDisabledBefore) { Disable-Pkg $setupPkg }
        [void](Run-Tv -params @('getprop','ro.product.model'))
        if (-not $stockDisabledBefore) { Disable-Pkg $stockPkg }
        Set-Home $customActivity
        if (-not (Is-Custom-Focused)) { Fail 'The physical HOME intent did not open CleanXiaomiTV.' }
        Write-Host 'ADB HOME test opens CleanXiaomiTV.' -ForegroundColor Green
        Write-Warning 'Before accepting, press the REAL remote HOME and test Netflix, YouTube, Live TV, HDMI/Input, Chromecast from a phone, Assistant, volume and Ethernet.'
        Write-Warning 'Do NOT reboot until testing and acceptance are finished.'
        $accepted = Read-Host 'Type KEEP only if ALL checks pass; anything else automatically restores Google TV Home'
        if ($accepted -cne 'KEEP') { Fail 'Verification not accepted by user. Restoring Google TV Home.' }
        Snapshot 'after_switch'
        Write-Host 'SUCCESS: Home switch accepted. Keep the restore script available.' -ForegroundColor Green
    } catch {
        Write-Warning ('Switch failed: ' + $_.Exception.Message)
        Write-Warning 'Attempting automatic restore...'
        try {
            if (-not $stockDisabledBefore) { Enable-Pkg $stockPkg }
            if (-not $setupDisabledBefore) { Enable-Pkg $setupPkg }
            Set-Home $stockActivity
            [void](Run-Tv -params @('am','start','-n',$stockActivity))
            Write-Host 'Original Google TV Home restored.' -ForegroundColor Green
        } catch { Write-Warning ('Auto-restore may have failed: ' + $_.Exception.Message) }
        throw
    }
}
function Restore {
    Connect-Tv
    if (-not (Installed $stockPkg)) { Fail 'Original launcher APK missing. Stop and contact support.' }
    $answer = Read-Host 'Type RESTORE to re-enable Google TV Launcher and setupwraith'
    if ($answer -cne 'RESTORE') { Write-Host 'Cancelled.'; return }
    # Enable both even if prior state file is missing, to recover HOME after a failed manual switch.
    Enable-Pkg $stockPkg
    Enable-Pkg $setupPkg
    Set-Home $stockActivity
    [void](Run-Tv -params @('am','start','-n',$stockActivity))
    Write-Host 'Restore completed. Press physical HOME.' -ForegroundColor Green
    Write-Host (Current-Home)
}

try {
    switch ($Action) {
        'status' { Status }
        'switch' { Invoke-HomeSwitch }
        'restore' { Restore }
    }
} catch {
    Write-Host ('[ERROR] ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
