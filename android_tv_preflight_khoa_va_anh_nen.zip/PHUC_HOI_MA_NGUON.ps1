$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backup = Join-Path $root 'state\appearance-backup'
$javaRoot = Join-Path $root 'work\CleanXiaomiTV-main\launcher\app\src\main\java\com\gathin\tvhome'
foreach($name in @('MainActivity.java','GlassDrawable.java','GlassView.java','DockDecoration.java')) {
    $file = Join-Path $backup $name
    if (-not (Test-Path $file)) { throw "Backup file missing: $file" }
}
foreach($name in @('MainActivity.java','GlassDrawable.java','GlassView.java','DockDecoration.java')) {
    Copy-Item -LiteralPath (Join-Path $backup $name) -Destination (Join-Path $javaRoot $name) -Force
}
foreach($name in @('AppearancePrefs.java','AppearanceSettings.java')) {
    $file = Join-Path $javaRoot $name
    if (Test-Path $file) { Remove-Item -LiteralPath $file }
}
Write-Host 'Appearance source rolled back. TV apps/settings were not changed.' -ForegroundColor Green
