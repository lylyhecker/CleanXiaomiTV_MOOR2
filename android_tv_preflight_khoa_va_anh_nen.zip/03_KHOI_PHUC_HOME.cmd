@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0MOOR2_HomeFix.ps1" -Action restore %*
if errorlevel 1 echo [ERROR] See message above.
pause
