# CleanXiaomiTV Home Fix - MiTV-MOOR2 (venom / Android 11 / firmware 1879)

**Quan trọng:** Dành cho TV đã cài CleanXiaomiTV, có kết nối ADB qua Wi-Fi. Không cần build lại APK. Công cụ sử dụng đúng package `com.majnioui.cleanxiaomitv` và MainActivity `com.gathin.tvhome.MainActivity` của dự án CleanXiaomiTV.

## Cách sử dụng

1. Giải nén thư mục này vào **cùng thư mục chứa `MOOR2.ps1`** của bộ cài trước. Có thể đặt `adb.exe` cạnh các CMD, hoặc giữ `adb.exe` trong PATH/Android SDK.
2. Giữ TV kết nối Wi-Fi và bật ADB debugging.
3. Chạy `01_KIEM_TRA_HOME.cmd` để chụp trạng thái hiện tại. File chẩn đoán nằm trong `state/`.
4. Chạy `02_CHUYEN_HOME_AN_TOAN.cmd`. Công cụ kiểm tra ứng dụng, thử đặt Home và bấm Home qua ADB. Nếu thành công thì **không tắt bất kỳ ứng dụng hệ thống nào**.
5. Nếu Google TV vẫn chiếm Home, công cụ kiểm tra danh tính ứng dụng đã lưu Wi-Fi. Nếu mạng có thể thuộc `setupwraith` hoặc không xác định được, công cụ **dừng an toàn**, không cố tắt dịch vụ. Nếu an toàn, công cụ mới yêu cầu bạn nhập `SWITCH` trước khi thay đổi.
6. Kiểm tra nút **Home thực** trên remote và kiểm tra mạng Wi-Fi, Netflix, YouTube, Chromecast, Live TV/HDMI, Input, Settings, âm lượng. Chỉ reboot sau khi các mục này đều tốt.
7. Chạy `03_KHOI_PHUC_HOME.cmd` nếu muốn quay lại Google TV. Script sẽ bật lại Google TV Launcher + setupwraith và đặt Google TV làm Home.

## Nếu được báo: setupwraith owns a saved Wi-Fi network

Không cố dùng `pm disable-user` bằng tay! Trên TV, vào **Settings → Network & Internet**, chọn mạng Wi-Fi đang dùng, **Forget**, rồi kết nối lại với cùng mạng. Việc này có thể cấp lại quyền sở hữu mạng cho Android thay vì setupwraith. Kết nối lại ADB nếu cần, sau đó chạy `01_KIEM_TRA_HOME.cmd` rồi `02_CHUYEN_HOME_AN_TOAN.cmd` lần nữa. Nếu không rõ hoặc không thể xác minh, giữ nguyên launcher gốc và gửi file chẩn đoán.

## Khôi phục khẩn cấp bằng CMD

Nếu Home bị lỗi nhưng ADB vẫn vào được:

```cmd
adb shell pm enable --user 0 com.google.android.apps.tv.launcherx
adb shell pm enable --user 0 com.google.android.tungsten.setupwraith
adb shell cmd package set-home-activity --user 0 com.google.android.apps.tv.launcherx/com.google.android.apps.tv.launcherx.home.HomeActivity
adb shell am start -n com.google.android.apps.tv.launcherx/com.google.android.apps.tv.launcherx.home.HomeActivity
```

**Không** sử dụng `pm uninstall`, không tắt ứng dụng Live TV, Bluetooth, Cast hay cập nhật OTA.

Nếu mạng Wi-Fi mất sau khi thao tác: khôi phục kết nối trực tiếp trên TV bằng remote (hoặc bàn phím USB), sau đó bật lại debugging nếu nó bị tắt và chạy các lệnh khôi phục.

## Ghi chú kỹ thuật

- Trên MiTV-MOOR2, launcher Google TV (`launcherx`) và wizard (`setupwraith`) có thể giành HOME dù `set-home-activity` báo Success.
- Mỗi lệnh `pm disable-user` là một lần gọi ADB riêng; trạng thái được xác minh lại bằng `pm list packages -d`.
- Trạng thái trước/sau được lưu vào `state/`; công cụ không sửa ứng dụng xem phim, dịch vụ TV, Chromecast hoặc firmware.
- Cập nhật sau này có thể khôi phục launcher gốc; cần chẩn đoán lại trước khi đổi Home.
