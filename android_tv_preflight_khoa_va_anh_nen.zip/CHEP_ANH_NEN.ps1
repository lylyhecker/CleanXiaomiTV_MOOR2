$ErrorActionPreference = 'Stop'
$local = Read-Host 'Drag a JPG/PNG/WebP image here, or enter its full path'
$local = $local.Trim('"').Trim()
if (-not (Test-Path -LiteralPath $local -PathType Leaf)) { throw "Image not found: $local" }
if ([IO.Path]::GetExtension($local) -notin @('.jpg','.jpeg','.png','.webp','.JPG','.JPEG','.PNG','.WEBP')) {
    throw 'Choose a JPG, PNG, or WebP image.'
}
$root = $PSScriptRoot
$adb = (Get-Command adb.exe -ErrorAction SilentlyContinue).Source
if (-not $adb) {
    $candidate = Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'
    if (Test-Path $candidate) { $adb = $candidate }
}
if (-not $adb) { throw 'adb.exe not found. Place it in PATH or install Android SDK Platform-Tools.' }
$deviceLines = @(& $adb devices)
$devices = @($deviceLines | ForEach-Object { if ($_ -match '^([^\s]+)\s+device\s*$') { $Matches[1] } })
if ($devices.Count -ne 1) { throw "Expected 1 online ADB device; found $($devices.Count). Check adb devices." }
$serial = $devices[0]
$model = (& $adb -s $serial shell getprop ro.product.model).Trim()
if ($model -ne 'MiTV-MOOR2') { throw "Wrong device: $model" }
$dest = '/sdcard/Android/data/com.majnioui.cleanxiaomitv/files/moor2_custom.jpg'
& $adb -s $serial push $local $dest
if ($LASTEXITCODE -ne 0) {
    Write-Warning 'Direct push to Android/data failed. Trying the debug app sandbox (run-as).'
    $temp = '/data/local/tmp/moor2_custom_wallpaper.jpg'
    & $adb -s $serial push $local $temp
    if ($LASTEXITCODE -ne 0) { throw 'Cannot transfer image to TV. Use the TV file picker instead.' }
    & $adb -s $serial shell run-as com.majnioui.cleanxiaomitv cp $temp $dest
    $copied = ($LASTEXITCODE -eq 0)
    & $adb -s $serial shell rm -f $temp
    if (-not $copied) { throw 'App sandbox did not accept copy. Use the TV file picker instead.' }
}
& $adb -s $serial shell ls -l $dest
if ($LASTEXITCODE -ne 0) {
    & $adb -s $serial shell run-as com.majnioui.cleanxiaomitv ls -l $dest
    if ($LASTEXITCODE -ne 0) { throw 'Transfer could not be verified.' }
}
Write-Host 'Image copied. Open CleanXiaomiTV > Settings > Appearance > Background > Use ADB image.' -ForegroundColor Green
