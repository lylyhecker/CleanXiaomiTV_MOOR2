# CleanXiaomiTV – Giao diện tùy chỉnh cho MiTV-MOOR2

Phiên bản mở rộng mã nguồn `majnioui/CleanXiaomiTV` cho Xiaomi MiTV-MOOR2 (venom) Android 11, bộ build Windows đã chuẩn bị trước đó.

## Chức năng mới trên TV

Vào **CleanXiaomiTV → Settings (biểu tượng bánh răng góc trên) → Tuỳ chỉnh giao diện / Appearance**.

- **Ảnh nền / Background**: Bing tự thay đổi, đen, xanh đêm, tím đêm, chọn ảnh từ ứng dụng quản lý tệp trên TV/USB, hoặc dùng ảnh tải từ ADB. Có thể trở về kiểu ảnh nền mặc định của theme.
- **Độ trong suốt kính**: 0–95%. Số càng cao, phần nền càng hiện rõ qua Liquid Glass; xác nhận **Áp dụng** để xem kết quả.
- **Màu kính**: trắng tự nhiên, xanh băng, tím nhạt, xám khói.
- **Bo góc kính**: 0–100%, áp dụng vào các thành phần Liquid Glass.
- **Đặt lại**: trả về thiết lập ban đầu của bản nâng cấp; giữ nguyên Dock và các ứng dụng.

Các giá trị được lưu bằng `SharedPreferences` thuộc launcher. Sau khi khởi động lại TV, chúng vẫn còn. Ảnh chọn từ TV/USB được nén JPEG và sao lưu vào thư mục riêng của launcher, không phụ thuộc ổ USB về sau.

## Cài trên Windows – không phải cài lại SDK

1. Nếu bạn **đã có** `C:\Users\bahoa\Downloads\android_tv_preflight\work\CleanXiaomiTV-main` do bộ cài trước tạo, chỉ cần giải nén **bản vá** vào `C:\Users\bahoa\Downloads\android_tv_preflight` (chọn gộp thư mục).
2. Chạy **`01_NANG_CAP_GIAO_DIEN.cmd`**. Công cụ sẽ vá các file Java, sao lưu bản gốc bên ngoài thư mục `res/`.
3. Chạy **`01_BUILD_APK.cmd`** có sẵn từ bộ cài trước. Nếu không thấy file này, hãy dùng **bản đầy đủ** và đặt các file vào thư mục `android_tv_preflight` cũ.
4. Khi báo build thành công và có `CleanXiaomiTV_MOOR2.apk`, chạy **`02_CAI_THU.cmd`** để cài bản cập nhật qua ADB. *Package ID vẫn là `com.majnioui.cleanxiaomitv`.*
5. Mở CleanXiaomiTV rồi chọn bánh răng > Tuỳ chỉnh giao diện.

Không cần chạy `03_DAT_HOME.cmd` hay tắt ứng dụng hệ thống để sử dụng phần tùy chỉnh. Nút Home trên remote vẫn có thể về launcher gốc nếu chưa hoàn tất bước đặt Home riêng.

## Chọn ảnh cá nhân

Từ TV: **Background → Chọn ảnh từ TV hoặc USB**, chọn ảnh JPG/PNG/WebP qua trình quản lý tài liệu Android. Nếu TV không có trình chọn tệp, dùng `06_CHEP_ANH_NEN.cmd` ở Windows để đẩy ảnh theo ADB, rồi vào **Background → Dùng ảnh đã chép qua ADB**. Ảnh quá lớn được giảm kích thước khi chọn qua trình quản lý tệp để tiết kiệm bộ nhớ.

Nếu trình chuyển ảnh từ PC thông báo Permission denied tại `/sdcard/Android/data/...`, dùng phương án chọn ảnh trực tiếp trên TV/USB. Điều này phụ thuộc firmware, không nên root hay tắt bảo vệ hệ thống chỉ để chép ảnh nền.

## Khôi phục mã nguồn

Chạy `02_PHUC_HOI_MA_NGUON.cmd` (bản vá chỉ khôi phục những file Java được thay đổi; không xóa dữ liệu ứng dụng). Sau đó build lại bằng `01_BUILD_APK.cmd` và cài lại APK nếu muốn quay về giao diện trước khi nâng cấp.

## Giới hạn kiểm thử

Bản vá được kiểm tra tĩnh, **chưa chạy build APK thực tế bằng Windows/Android SDK và chưa thử giao diện trên TV thật**. Nếu Gradle báo khác biệt với commit source hiện tại, script sẽ dừng để tránh ghi đè nhầm. Gửi log Gradle mới để xác định lỗi.

Các file bản vá mới đều nằm trong `launcher/app/src/main/java/com/gathin/tvhome/` hoặc script PC. Không chạy debloat, không xóa package, không sửa firmware. Netflix / YouTube / TV360 / VieON / Live TV / Chromecast / Assistant được giữ nguyên.

Mã nguồn gốc: https://github.com/majnioui/CleanXiaomiTV (MIT).
