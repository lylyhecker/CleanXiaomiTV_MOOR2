@echo off
setlocal
cd /d "%~dp0"
echo Fixing the invalid config.xml.original-moor2 backup via MOOR2.ps1 and rebuilding...
call "%~dp001_BUILD_APK.cmd" %*
