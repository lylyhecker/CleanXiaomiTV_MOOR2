@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0NANG_CAP_GIAO_DIEN.ps1"
if errorlevel 1 (
  echo.
  echo [ERROR] Upgrade stopped. Source is unchanged if version anchors did not match.
  pause
  exit /b 1
)
echo.
echo Upgraded. Run the existing 01_BUILD_APK.cmd, then 02_CAI_THU.cmd.
pause
