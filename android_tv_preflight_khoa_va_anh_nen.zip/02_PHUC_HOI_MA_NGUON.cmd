@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PHUC_HOI_MA_NGUON.ps1"
if errorlevel 1 echo [ERROR] Rollback failed.
pause
