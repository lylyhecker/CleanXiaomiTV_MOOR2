﻿param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('build','install','home','restore','status','sdksetup')]
    [string]$Action,
    [string]$Serial = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$work = Join-Path $root 'work'
$state = Join-Path $root 'state'
$repo = Join-Path $work 'CleanXiaomiTV-main'
$apk = Join-Path $root 'CleanXiaomiTV_MOOR2.apk'
$customPackage = 'com.majnioui.cleanxiaomitv'
$customComponent = 'com.majnioui.cleanxiaomitv/com.gathin.tvhome.MainActivity'
$stockPackage = 'com.google.android.apps.tv.launcherx'
$stockComponent = 'com.google.android.apps.tv.launcherx/com.google.android.apps.tv.launcherx.home.HomeActivity'
$expectedModel = 'MiTV-MOOR2'
$expectedDevice = 'venom'

function Die([string]$Message) { throw $Message }
function Require-Path([string]$Path, [string]$Message) {
    if (-not (Test-Path -LiteralPath $Path)) { Die $Message }
}
function Run-Checked([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { Die "Command failed (code $LASTEXITCODE): $Exe $($Arguments -join ' ')" }
}
function Locate-Adb {
    $local = Join-Path $root 'adb.exe'
    if (Test-Path $local) { return $local }
    $cmd = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach($sdk in @($env:ANDROID_HOME,$env:ANDROID_SDK_ROOT,(Join-Path $env:LOCALAPPDATA 'Android\Sdk'))) {
        if ($sdk) {
            $p = Join-Path $sdk 'platform-tools\adb.exe'
            if (Test-Path $p) { return $p }
        }
    }
    Die 'ADB not found. Add Android platform-tools to PATH, or put adb.exe in this folder.'
}
function Pick-TV {
    $script:adb = Locate-Adb
    $lines = @(& $script:adb devices)
    $online = @($lines | ForEach-Object {
        if ($_ -match '^([^\s]+)\s+device\s*$') { $Matches[1] }
    })
    if (-not $Serial -and $online.Count -eq 0) {
        $hostIp = Read-Host 'TV not detected. Enter the TV Wi-Fi IP (or press Enter to cancel)'
        if ([string]::IsNullOrWhiteSpace($hostIp)) { Die 'No ADB device found.' }
        Run-Checked $script:adb @('connect', "$($hostIp):5555")
        $online = @((& $script:adb devices) | ForEach-Object {
            if ($_ -match '^([^\s]+)\s+device\s*$') { $Matches[1] }
        })
    }
    if ($Serial) {
        if ($online -cnotcontains $Serial) { Die "ADB device $Serial is not online. Use adb devices first." }
        $script:tv = $Serial
    } elseif ($online.Count -eq 1) {
        $script:tv = $online[0]
    } else {
        Die "Found $($online.Count) devices ($($online -join ', ')). Run the PowerShell script with -Serial '<serial>' to choose exactly one."
    }
    $model = ( & $script:adb -s $script:tv shell getprop ro.product.model ).Trim()
    $device = ( & $script:adb -s $script:tv shell getprop ro.product.device ).Trim()
    $android = ( & $script:adb -s $script:tv shell getprop ro.build.version.release ).Trim()
    if ($LASTEXITCODE -ne 0) { Die 'Unable to read TV properties over ADB.' }
    if ($model -ne $expectedModel -or $device -ne $expectedDevice -or $android -ne '11') {
        Die "Wrong TV: $model / $device / Android $android. Expected MiTV-MOOR2 (venom), Android 11. No changes made."
    }
    $fp = ( & $script:adb -s $script:tv shell getprop ro.build.fingerprint ).Trim()
    Write-Host "TV verified: $model / $device / Android $android / $script:tv" -ForegroundColor Green
    Write-Host "Firmware: $fp"
    if ($fp -notlike '*RTM5.220609.003/1879:*') {
        Write-Warning 'Firmware is not the previously reported build 1879. Review compatibility before switching Home.'
    }
}
function TV-Read([string[]]$Arguments) {
    $output = @(& $script:adb -s $script:tv shell @Arguments 2>&1)
    if ($LASTEXITCODE -ne 0) { Die "ADB shell failed: $($Arguments -join ' ')`n$($output -join "`n")" }
    return ($output -join "`n").Trim()
}
function Prepare-State {
    New-Item -ItemType Directory -Force -Path $state | Out-Null
    $backup = Join-Path $state 'backup_first_install'
    if (-not (Test-Path $backup)) {
        New-Item -ItemType Directory -Path $backup -Force | Out-Null
        $queries = @{
            'installed_packages.txt' = @('pm','list','packages')
            'disabled_packages.txt' = @('pm','list','packages','-d')
            'home_before.txt' = @('cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
            'home_candidates.txt' = @('cmd','package','query-activities','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
            'firmware.txt' = @('getprop','ro.build.fingerprint')
        }
        foreach ($name in $queries.Keys) {
            $value = TV-Read $queries[$name]
            [System.IO.File]::WriteAllText((Join-Path $backup $name),$value,[System.Text.Encoding]::UTF8)
        }
        Write-Host "First-install device snapshot: $backup"
    }
}
function Set-XmlValue([xml]$doc, [string]$element, [string]$key, [string]$value, [bool]$required=$false) {
    $node = $doc.SelectSingleNode("/resources/$element" + "[@name='$key']")
    if ($null -eq $node) {
        if ($required) { Die "Upstream config format changed: missing $element/$key. Refusing to save partial edits." }
        return
    }
    $node.InnerText = $value
}
function Download-Upstream {
    New-Item -ItemType Directory -Path $work -Force | Out-Null
    $cfg = Join-Path $repo 'launcher\app\src\main\res\values\config.xml'
    if (Test-Path $cfg) {
        Require-Path (Join-Path $repo 'launcher\gradlew.bat') 'Existing source folder is incomplete (missing gradlew.bat). Delete work/CleanXiaomiTV-main and rerun.'
        Write-Host 'Using the existing downloaded source in work/CleanXiaomiTV-main.'
        return
    }
    $sourceZip = Join-Path $work 'CleanXiaomiTV-upstream-main.zip'
    $url = 'https://github.com/majnioui/CleanXiaomiTV/archive/refs/heads/main.zip'
    Write-Host "Downloading original CleanXiaomiTV from $url"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $sourceZip -UseBasicParsing -TimeoutSec 120
        Expand-Archive -LiteralPath $sourceZip -DestinationPath $work -Force
    } catch {
        Die "Could not download upstream project. Download the ZIP via browser from $url, extract so that work/CleanXiaomiTV-main/launcher exists, then rerun. Detail: $_"
    }
    Require-Path $cfg 'Upstream source was not extracted as expected. No changes made.'
}
function Patch-Launcher {
    $cfg = Join-Path $repo 'launcher\app\src\main\res\values\config.xml'
    $manifest = Join-Path $repo 'launcher\app\src\main\AndroidManifest.xml'
    Require-Path $cfg 'Missing launcher config.xml.'
    Require-Path $manifest 'Missing AndroidManifest.xml.'
    $manifestRaw = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8
    if (-not $manifestRaw.Contains('android.intent.category.LEANBACK_LAUNCHER')) {
        Die 'Upstream launcher no longer declares Android TV app visibility; cannot safely build.'
    }
    $gradle = Join-Path $repo 'launcher\app\build.gradle'
    Require-Path $gradle 'Missing launcher build.gradle.'
    if (-not ((Get-Content $gradle -Raw -Encoding UTF8) -match "applicationId\s+'com\.majnioui\.cleanxiaomitv'")) {
        Die 'Unexpected app applicationId. This patch is restricted to com.majnioui.cleanxiaomitv.'
    }
    [xml]$doc = Get-Content -LiteralPath $cfg -Raw -Encoding UTF8
    $dock = $doc.SelectSingleNode("/resources/string-array[@name='dock_apps']")
    if ($null -eq $dock) { Die 'Missing dock_apps element. No changes saved.' }
    # Android treats every file in res/values as a resource; backups must live outside res.
    $sourceBackups = Join-Path $state 'source-backups'
    New-Item -ItemType Directory -Force -Path $sourceBackups | Out-Null
    $original = Join-Path $sourceBackups 'config.original.xml'
    $legacyOriginal = $cfg + '.original-moor2'
    if (Test-Path -LiteralPath $legacyOriginal -PathType Leaf) {
        if (-not (Test-Path -LiteralPath $original -PathType Leaf)) {
            Copy-Item -LiteralPath $legacyOriginal -Destination $original -Force
        }
        Remove-Item -LiteralPath $legacyOriginal -Force
        Write-Host 'Removed invalid backup from res/values; preserved the original under state/source-backups.' -ForegroundColor Green
    }
    if (-not (Test-Path -LiteralPath $original -PathType Leaf)) {
        Copy-Item -LiteralPath $cfg -Destination $original -Force
    }
    $dock.RemoveAll()
    $dock.SetAttribute('name','dock_apps')
    foreach($pkg in @('com.netflix.ninja','com.google.android.youtube.tv','com.viettel.tv360.tv','com.vieon.tv')) {
        $item = $doc.CreateElement('item')
        $item.InnerText = $pkg
        [void]$dock.AppendChild($item)
    }
    Set-XmlValue $doc 'string' 'launcher_name' 'CleanXiaomiTV MOOR2' $true
    Set-XmlValue $doc 'string' 'live_tv_package' 'com.mitv.livetv' $true
    Set-XmlValue $doc 'integer' 'columns' '4' $true
    Set-XmlValue $doc 'integer' 'grid_columns' '5'
    Set-XmlValue $doc 'bool' 'advanced_effects' 'false'
    Set-XmlValue $doc 'bool' 'home_prayer' 'false'
    Set-XmlValue $doc 'bool' 'dream_prayer' 'false'
    Set-XmlValue $doc 'bool' 'dream_athkar' 'false'
    Set-XmlValue $doc 'bool' 'dream_photos' 'false'
    Set-XmlValue $doc 'bool' 'module_cards' 'false'
    Set-XmlValue $doc 'bool' 'home_photo' 'true'
    Set-XmlValue $doc 'string' 'weather_latitude' ''
    Set-XmlValue $doc 'string' 'weather_longitude' ''
    Set-XmlValue $doc 'string' 'weather_place' ''
    $doc.Save($cfg)
    Write-Host 'Customized dock: Netflix | YouTube | TV360 | VieON' -ForegroundColor Cyan
    Write-Host 'Live TV and Inputs retained. Unused prayer/athkar disabled. No system packages altered.'
}
function Find-JdkHome {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($name in @('MOOR2_JAVA_HOME','JAVA_HOME','JDK_HOME','STUDIO_JDK','ANDROID_STUDIO_JDK','GRADLE_JAVA_HOME')) {
        $value = [Environment]::GetEnvironmentVariable($name, 'Process')
        if (-not [string]::IsNullOrWhiteSpace($value)) { [void]$candidates.Add($value.Trim('"')) }
    }
    $bases = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    foreach ($base in $bases) {
        foreach ($relative in @('Android\Android Studio\jbr','Android\Android Studio\jre','Programs\Android Studio\jbr')) {
            [void]$candidates.Add((Join-Path $base $relative))
        }
        foreach ($relative in @('Eclipse Adoptium','Java','Microsoft','Amazon Corretto','BellSoft','Zulu','OpenJDK','Microsoft OpenJDK')) {
            $container = Join-Path $base $relative
            if (-not (Test-Path -LiteralPath $container -PathType Container)) { continue }
            foreach ($dir in @(Get-ChildItem -LiteralPath $container -Directory -ErrorAction SilentlyContinue)) {
                [void]$candidates.Add($dir.FullName)
            }
        }
    }
    if ($env:USERPROFILE) {
        $jdks = Join-Path $env:USERPROFILE '.jdks'
        if (Test-Path $jdks -PathType Container) {
            foreach ($dir in @(Get-ChildItem -LiteralPath $jdks -Directory -ErrorAction SilentlyContinue)) {
                [void]$candidates.Add($dir.FullName)
            }
        }
    }
    $javacOnPath = Get-Command javac.exe -ErrorAction SilentlyContinue
    if ($javacOnPath -and $javacOnPath.Source) {
        [void]$candidates.Add((Split-Path -Parent (Split-Path -Parent $javacOnPath.Source)))
    }
    $seen = @{}
    foreach ($candidate in $candidates) {
        if (-not $candidate -or $seen.ContainsKey($candidate.ToLowerInvariant())) { continue }
        $seen[$candidate.ToLowerInvariant()] = $true
        $java = Join-Path $candidate 'bin\java.exe'
        $javac = Join-Path $candidate 'bin\javac.exe'
        if (-not ((Test-Path -LiteralPath $java -PathType Leaf) -and (Test-Path -LiteralPath $javac -PathType Leaf))) { continue }
        try {
            $output = (& $javac '-version' | Out-String).Trim()
            $result = $LASTEXITCODE
            if ($result -ne 0 -or $output -notmatch 'javac\s+(\d+)') { continue }
            $major = [int]$Matches[1]
            # The repository uses Gradle 8.9, which cannot run on every later Java release.
            if ($major -ge 17 -and $major -le 22) {
                Write-Host "JDK found: $output at $candidate" -ForegroundColor Green
                return $candidate
            }
            Write-Warning "Ignoring unsupported JDK $major at $candidate (use JDK 17 or 21)."
        } catch {
            Write-Warning "Cannot run javac at $candidate : $_"
        }
    }
    return $null
}
function Install-Jdk17 {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        Write-Warning 'winget.exe is not installed or available in this Windows account.'
        Write-Host 'Download JDK 17 manually: https://adoptium.net/temurin/releases/?version=17&package=jdk'
        return $false
    }
    Write-Host 'The launcher needs JDK 17. The official Eclipse Temurin JDK can be installed with winget.'
    Write-Host 'This installs Java on the Windows PC only. It does NOT change any TV package.'
    $confirm = Read-Host 'Type INSTALL to install JDK 17 with winget; press Enter to skip'
    if ($confirm -cne 'INSTALL') { return $false }
    & $winget.Source install --id EclipseAdoptium.Temurin.17.JDK --exact --source winget --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "winget finished with exit code $LASTEXITCODE. You may need administrator approval or a manual installation."
        return $false
    }
    Write-Host 'Installation command finished. Checking newly installed JDK...'
    return $true
}
function Configure-Java {
    $javaHome = Find-JdkHome
    if (-not $javaHome) {
        Write-Warning 'JDK 17 or 21 not detected in JAVA_HOME, Android Studio JBR, PATH or standard install folders.'
        [void](Install-Jdk17)
        $javaHome = Find-JdkHome
    }
    if (-not $javaHome) {
        Die 'JDK missing. Install JDK 17: winget install --id EclipseAdoptium.Temurin.17.JDK -e ; or https://adoptium.net/temurin/releases/?version=17&package=jdk . Then rerun 01_BUILD_APK.cmd.'
    }
    $env:JAVA_HOME = $javaHome
    $env:PATH = (Join-Path $javaHome 'bin') + ';' + $env:PATH
    Write-Host "JAVA_HOME for this build: $env:JAVA_HOME"
    Run-Checked (Join-Path $javaHome 'bin\javac.exe') @('-version')
}
function Find-SdkHome {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($name in @('MOOR2_ANDROID_SDK','ANDROID_HOME','ANDROID_SDK_ROOT')) {
        $value = [Environment]::GetEnvironmentVariable($name, 'Process')
        if (-not [string]::IsNullOrWhiteSpace($value)) { [void]$candidates.Add($value.Trim('"')) }
    }
    if ($env:LOCALAPPDATA) { [void]$candidates.Add((Join-Path $env:LOCALAPPDATA 'Android\Sdk')) }
    if ($env:USERPROFILE) { [void]$candidates.Add((Join-Path $env:USERPROFILE 'AppData\Local\Android\Sdk')) }
    if ($env:ProgramFiles) { [void]$candidates.Add((Join-Path $env:ProgramFiles 'Android\Sdk')) }
    [void]$candidates.Add('C:\Android\Sdk')

    $seen = @{}
    $best = $null
    $bestScore = -1
    foreach ($candidate in $candidates) {
        if (-not $candidate) { continue }
        try { $candidate = [System.IO.Path]::GetFullPath($candidate) } catch { continue }
        if ($seen.ContainsKey($candidate.ToLowerInvariant())) { continue }
        $seen[$candidate.ToLowerInvariant()] = $true
        $score = 0
        if (Test-Path -LiteralPath $candidate -PathType Container) { $score += 1 }
        if (Test-Path -LiteralPath (Join-Path $candidate 'cmdline-tools\latest\bin\sdkmanager.bat') -PathType Leaf) { $score += 4 }
        if (Test-Path -LiteralPath (Join-Path $candidate 'platforms\android-34\android.jar') -PathType Leaf) { $score += 8 }
        if (Test-Path -LiteralPath (Join-Path $candidate 'build-tools\34.0.0\aapt.exe') -PathType Leaf) { $score += 8 }
        if (Test-Path -LiteralPath (Join-Path $candidate 'platform-tools\adb.exe') -PathType Leaf) { $score += 2 }
        $explicit = [Environment]::GetEnvironmentVariable('MOOR2_ANDROID_SDK', 'Process')
        if ($score -eq 0 -and (-not $explicit -or $candidate -ine $explicit.Trim('"'))) { continue }
        if ($score -gt $bestScore) { $bestScore = $score; $best = $candidate }
    }
    if (-not $best) {
        if ($env:LOCALAPPDATA) { $best = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
        else { Die 'Unable to determine an Android SDK destination on this Windows PC.' }
    }
    return $best
}
function Get-SdkManager([string]$Sdk) {
    foreach ($rel in @('cmdline-tools\latest\bin\sdkmanager.bat','cmdline-tools\bin\sdkmanager.bat','tools\bin\sdkmanager.bat')) {
        $p = Join-Path $Sdk $rel
        if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
    }
    $cmdlineBase = Join-Path $Sdk 'cmdline-tools'
    if (Test-Path -LiteralPath $cmdlineBase -PathType Container) {
        foreach ($d in @(Get-ChildItem -LiteralPath $cmdlineBase -Directory -ErrorAction SilentlyContinue)) {
            $p = Join-Path $d.FullName 'bin\sdkmanager.bat'
            if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
        }
    }
    return $null
}
function Sdk-Ready([string]$Sdk) {
    $platformOk = Test-Path (Join-Path $Sdk 'platforms\android-34\android.jar') -PathType Leaf
    $buildToolsOk = Test-Path (Join-Path $Sdk 'build-tools\34.0.0\aapt.exe') -PathType Leaf
    $platformToolsOk = Test-Path (Join-Path $Sdk 'platform-tools\adb.exe') -PathType Leaf
    return ($platformOk -and $buildToolsOk -and $platformToolsOk)
}
function Install-SdkCli([string]$Sdk) {
    # Download published on the official Android Studio page, 2026-10-24.
    $url = 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip'
    $expectedSha256 = '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
    $cache = Join-Path $work 'android-cli-tools-15859902.zip'
    $stage = Join-Path $work 'android-cli-unpack'
    $target = Join-Path $Sdk 'cmdline-tools\latest'
    if (Get-SdkManager $Sdk) { return }
    if (Test-Path $target) {
        Die "SDK cmdline-tools/latest exists but sdkmanager.bat is missing: $target. Repair in Android Studio SDK Manager; refusing to overwrite existing data."
    }
    New-Item -ItemType Directory -Force -Path $work | Out-Null
    if (Test-Path $cache) {
        if ((Get-FileHash -LiteralPath $cache -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedSha256) {
            Remove-Item -LiteralPath $cache -Force
        }
    }
    if (-not (Test-Path $cache)) {
        Write-Host 'Downloading Android SDK Command-line Tools from Google (approximately 156 MB)...' -ForegroundColor Cyan
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $cache -TimeoutSec 600
        } catch {
            Die "Could not download Android SDK tools: $_`nOpen https://developer.android.com/studio#command-line-tools-only or install Android Studio."
        }
    }
    $actualSha256 = (Get-FileHash -LiteralPath $cache -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha256 -ne $expectedSha256) {
        Remove-Item -LiteralPath $cache -Force -ErrorAction SilentlyContinue
        Die "Android SDK download failed SHA256 verification. Expected $expectedSha256, got $actualSha256. Nothing was installed."
    }
    if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    Expand-Archive -LiteralPath $cache -DestinationPath $stage -Force
    $unpacked = Join-Path $stage 'cmdline-tools'
    Require-Path (Join-Path $unpacked 'bin\sdkmanager.bat') 'Google SDK tools ZIP has an unexpected layout.'
    New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
    Move-Item -LiteralPath $unpacked -Destination $target
    Write-Host "SDK Command-line Tools installed in $target" -ForegroundColor Green
}
function Configure-Sdk {
    $sdk = Find-SdkHome
    Write-Host "Android SDK location: $sdk"
    if (-not (Sdk-Ready $sdk)) {
        Write-Warning 'Android SDK 34 / Build-Tools 34.0.0 / Platform-Tools not fully installed.'
        Write-Host 'This will install Android developer tools on the Windows PC only (no changes to the TV).'
        Write-Host 'Google SDK license terms: https://developer.android.com/studio (read before continuing).'
        Write-Host 'The Command-line Tools download is approximately 156 MB; other packages need additional disk space and internet.'
        $confirm = Read-Host 'Type INSTALL to set up Android SDK components, or press Enter to cancel'
        if ($confirm -cne 'INSTALL') {
            Die 'Android SDK missing. Run 00_CAI_ANDROID_SDK.cmd and enter INSTALL, or use Android Studio > Settings > Android SDK.'
        }
        Install-SdkCli $sdk
        $manager = Get-SdkManager $sdk
        if (-not $manager) { Die "sdkmanager.bat not found after installation in $sdk" }
        $env:ANDROID_HOME = $sdk
        $env:ANDROID_SDK_ROOT = $sdk
        Write-Host 'Checking required SDK licenses. Review each prompt and type y to accept when appropriate.' -ForegroundColor Cyan
        & $manager '--licenses' "--sdk_root=$sdk"
        if ($LASTEXITCODE -ne 0) { Die 'SDK license step was not completed. Rerun setup and accept the licenses you agree to.' }
        Write-Host 'Installing Android API 34 + Build-Tools 34.0.0 + Platform-Tools...' -ForegroundColor Cyan
        Run-Checked $manager @('platforms;android-34','build-tools;34.0.0','platform-tools',"--sdk_root=$sdk")
    }
    if (-not (Sdk-Ready $sdk)) {
        Die "Android SDK installation incomplete at $sdk. Open Android Studio SDK Manager and verify Android API 34, Build-Tools 34.0.0, Platform-Tools."
    }
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    $env:PATH = (Join-Path $sdk 'platform-tools') + ';' + $env:PATH
    Write-Host "Android SDK ready: $sdk" -ForegroundColor Green
    Write-Host 'Android API 34, Build-Tools 34.0.0 and Platform-Tools detected.'
}

function Build-App {
    Download-Upstream
    Patch-Launcher
    Configure-Java
    Configure-Sdk
    $launcher = Join-Path $repo 'launcher'
    Require-Path (Join-Path $launcher 'gradlew.bat') 'Upstream project is missing gradlew.bat.'
    Push-Location $launcher
    try {
        Write-Host 'Building Android TV APK (debug signed) ...'
        Run-Checked (Join-Path $launcher 'gradlew.bat') @(':app:assembleDebug','--console=plain','--no-daemon')
    } finally { Pop-Location }
    $built = Join-Path $launcher 'app\build\outputs\apk\debug\app-debug.apk'
    Require-Path $built 'Gradle finished but app-debug.apk is missing.'
    Copy-Item -LiteralPath $built -Destination $apk -Force
    $checksum = (Get-FileHash -Path $apk -Algorithm SHA256).Hash
    [System.IO.File]::WriteAllText((Join-Path $root 'CleanXiaomiTV_MOOR2.apk.sha256'),$checksum,[System.Text.Encoding]::ASCII)
    Write-Host "APK created: $apk" -ForegroundColor Green
    Write-Host "SHA256: $checksum"
    Write-Host 'Next: run 02_CAI_THU.cmd. It will NOT change the default launcher.'
}
function Install-App {
    Require-Path $apk 'No APK yet: run 01_BUILD_APK.cmd first.'
    Pick-TV
    Prepare-State
    Write-Host 'Installing launcher without disabling any stock package...'
    Run-Checked $script:adb @('-s',$script:tv,'install','-r',$apk)
    $installed = TV-Read @('pm','path',$customPackage)
    if ($installed -notmatch 'package:') { Die 'TV did not report installed CleanXiaomiTV package.' }
    Write-Host 'Starting launcher for a visual test...'
    Run-Checked $script:adb @('-s',$script:tv,'shell','am','start','-n',$customComponent)
    Start-Sleep -Seconds 2
    try {
        $shot = Join-Path $state 'launcher-test.png'
        & $script:adb -s $script:tv shell screencap -p /sdcard/Download/cleanxiaomitv-moor2-test.png | Out-Null
        if ($LASTEXITCODE -eq 0) {
            & $script:adb -s $script:tv pull /sdcard/Download/cleanxiaomitv-moor2-test.png $shot | Out-Null
            if ((Test-Path $shot) -and (Get-Item $shot).Length -gt 0) { Write-Host "TV screenshot: $shot" }
        }
    } catch { Write-Warning 'Screenshot could not be captured; inspect the TV screen manually.' }
    Write-Host 'SUCCESS: launcher is installed and start was requested.' -ForegroundColor Green
    Write-Host 'Test Netflix, YouTube, TV360, VieON, Live TV/HDMI, D-pad, Settings and volume on the TV.'
    Write-Host 'Only after you confirm it works, run 03_DAT_HOME.cmd.'
}
function Set-Home {
    Pick-TV
    $installed = TV-Read @('pm','path',$customPackage)
    if ($installed -notmatch 'package:') { Die 'Custom launcher not installed. Run 02_CAI_THU.cmd first.' }
    Prepare-State
    Write-Host 'This attempts to choose custom Home, keeping the stock launcher enabled.' -ForegroundColor Yellow
    $confirm = Read-Host 'Type HOME to continue'
    if ($confirm -cne 'HOME') { Write-Host 'Cancelled.'; return }
    Write-Host 'Setting the default Home component...'
    Write-Host (TV-Read @('cmd','package','set-home-activity',$customComponent))
    Write-Host 'Resolved Home:'
    $resolved = TV-Read @('cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME')
    Write-Host $resolved
    Write-Host 'Sending HOME key...'
    Run-Checked $script:adb @('-s',$script:tv,'shell','input','keyevent','3')
    Start-Sleep -Seconds 2
    $activities = TV-Read @('dumpsys','activity','activities')
    $focused = @($activities -split '\r?\n' | Where-Object { $_ -match 'topResumedActivity|mFocusedApp|mResumedActivity' })
    Write-Host "Foreground diagnostic:`n$($focused -join "`n")"
    if ($focused -match [regex]::Escape($customPackage)) {
        Write-Host 'Custom launcher appears to be in the foreground.' -ForegroundColor Green
    } else {
        Write-Warning 'Could not confirm the custom launcher is in the foreground. Press the physical HOME button and check the TV; Google TV firmware can ignore set-home-activity.'
    }
    Write-Host 'Stock launcher is still enabled. Run 04_KHOI_PHUC_HOME.cmd to revert at any time.'
}
function Restore-Home {
    Pick-TV
    Write-Host 'Restore the original Google TV Home without disabling/uninstalling any system app.'
    $confirm = Read-Host 'Type RESTORE to continue'
    if ($confirm -cne 'RESTORE') { Write-Host 'Cancelled.'; return }
    $stock = TV-Read @('pm','path',$stockPackage)
    if ($stock -notmatch 'package:') { Die 'Stock Google TV launcher is missing; do not continue. Repair the TV first.' }
    Write-Host (TV-Read @('cmd','package','set-home-activity',$stockComponent))
    Run-Checked $script:adb @('-s',$script:tv,'shell','am','start','-n',$stockComponent)
    Write-Host 'Current Home resolution:'
    Write-Host (TV-Read @('cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME'))
    Write-Host 'Original Google TV launcher start requested. No uninstall performed.' -ForegroundColor Green
}
function Status-TV {
    Pick-TV
    Write-Host "\nInstalled custom launcher:"
    Write-Host (TV-Read @('pm','path',$customPackage))
    Write-Host "\nHOME resolution:"
    Write-Host (TV-Read @('cmd','package','resolve-activity','--brief','-a','android.intent.action.MAIN','-c','android.intent.category.HOME'))
    Write-Host "\nDisabled packages:"
    Write-Host (TV-Read @('pm','list','packages','-d'))
}

try {
    switch ($Action) {
        'build'    { Build-App }
        'sdksetup' { Configure-Java; Configure-Sdk }
        'install'  { Install-App }
        'home'     { Set-Home }
        'restore'  { Restore-Home }
        'status'   { Status-TV }
    }
} catch {
    Write-Host ('[ERROR] ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
