param([switch]$Build)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$repo = Join-Path $root 'work\CleanXiaomiTV-main'
$javaRoot = Join-Path $repo 'launcher\app\src\main\java\com\gathin\tvhome'
$src = Join-Path $root 'upgrade_files'
$state = Join-Path $root 'state\appearance-backup'
if (-not (Test-Path -LiteralPath $javaRoot -PathType Container)) {
    throw 'Source not found: work\CleanXiaomiTV-main. Run the previous 01_BUILD_APK.cmd once, then retry.'
}
$targets = @('MainActivity.java','GlassDrawable.java','GlassView.java','DockDecoration.java')
$utf8 = New-Object System.Text.UTF8Encoding($false)
$files = @{}
foreach ($name in $targets) {
    $file = Join-Path $javaRoot $name
    if (-not (Test-Path -LiteralPath $file)) { throw "Missing upstream source: $name" }
    $files[$name] = ([System.IO.File]::ReadAllText($file) -replace "`r`n", "`n")
}
if ($files['MainActivity.java'].Contains('AppearanceSettings.show(this, this::recreate);')) {
    Write-Host 'Appearance upgrade already applied. No duplicate changes.' -ForegroundColor Green
} else {
    function Change([string]$file, [string]$anchor, [string]$replacement) {
        $before = $files[$file]
        if (-not $before.Contains($anchor)) {
            throw "Source changed upstream; cannot safely find anchor in $file : $anchor. No files were written."
        }
        $after = $before.Replace($anchor, $replacement)
        $files[$file] = $after
    }
    # All patches are calculated in RAM; fail closed if the source version is unexpected.
    Change 'MainActivity.java' '        setContentView(R.layout.activity_main);' @'
        setContentView(R.layout.activity_main);
        AppearancePrefs.load(this);
'@
    Change 'MainActivity.java' @'
        root.setBackgroundColor(cfg.backgroundColor);
        if (cfg.wallpaper != null) showWallpaper(cfg.wallpaper);
        homePhotoOn = cfg.homePhoto && cfg.wallpaper == null;
'@ @'
        int bgMode = AppearancePrefs.backgroundMode(this);
        File chosenWallpaper = bgMode == AppearancePrefs.CUSTOM ? AppearancePrefs.customWallpaper(this)
                : bgMode == AppearancePrefs.ORIGINAL ? cfg.wallpaper : null;
        root.setBackgroundColor(AppearancePrefs.backgroundColor(bgMode, cfg.backgroundColor));
        if (chosenWallpaper != null) showWallpaper(chosenWallpaper);
        homePhotoOn = bgMode == AppearancePrefs.BING
                || (bgMode == AppearancePrefs.ORIGINAL && cfg.homePhoto && chosenWallpaper == null);
'@
    Change 'MainActivity.java' '        addSettingsRow(rows, popup, R.drawable.ic_settings, R.string.system_settings, 2);' @'
        addSettingsRow(rows, popup, R.drawable.ic_settings, R.string.system_settings, 2);
        addAppearanceRow(rows, popup);
'@
    Change 'MainActivity.java' '    private void addSettingsRow(LinearLayout rows, PopupWindow popup, int icon, int title, int action) {' @'
    private void addAppearanceRow(LinearLayout rows, PopupWindow popup) {
        View row = getLayoutInflater().inflate(R.layout.item_setting, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(R.drawable.ic_settings);
        ((TextView) row.findViewById(R.id.title)).setText("Tuỳ chỉnh giao diện / Appearance");
        row.findViewById(R.id.dot).setVisibility(View.GONE);
        row.findViewById(R.id.status).setVisibility(View.GONE);
        row.setOnClickListener(v -> {
            popup.dismiss();
            AppearanceSettings.show(this, this::recreate);
        });
        rows.addView(row);
    }
    private void addSettingsRow(LinearLayout rows, PopupWindow popup, int icon, int title, int action) {
'@
    Change 'MainActivity.java' @'
    @Override
    protected void onStart() {
'@ @'
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != AppearanceSettings.IMAGE_REQUEST || resultCode != RESULT_OK || data == null) return;
        if (AppearanceSettings.importImage(this, data.getData())) {
            Toast.makeText(this, "Đã đổi ảnh nền", Toast.LENGTH_SHORT).show();
            recreate();
        } else {
            Toast.makeText(this, "Không thể đọc ảnh. Thử JPG/PNG nhỏ hơn hoặc chép qua ADB.", Toast.LENGTH_LONG).show();
        }
    }
    @Override
    protected void onStart() {
'@
    Change 'MainActivity.java' '        on.setColor(0xF5FFFFFF);' @'
        on.setColor(android.graphics.Color.argb(AppearancePrefs.alpha(245), 255, 255, 255));
'@
    Change 'GlassDrawable.java' @'
        // One fill for the body of the glass: the blurred photo (veil already baked in) and the sheen on
'@ @'
        radius = Math.min(rect.height() / 2f, radius * AppearancePrefs.cornerScale());
        // One fill for the body of the glass: the blurred photo (veil already baked in) and the sheen on
'@
    Change 'GlassDrawable.java' '        p.setAlpha(alpha);' '        p.setAlpha(AppearancePrefs.alpha(alpha));'
    Change 'GlassDrawable.java' @'
            p.setColor(veil);
            c.drawRoundRect(rect, radius, radius, p);
'@ @'
            p.setColor(veil);
            p.setAlpha(AppearancePrefs.alpha((veil >>> 24) & 0xFF));
            c.drawRoundRect(rect, radius, radius, p);
'@
    Change 'GlassDrawable.java' @'
        p.setAlpha(255);
        // Edge: the same even line the pills and dock band had before the glass.
'@ @'
        int userTint = AppearancePrefs.tintColor();
        if (userTint != 0) {
            p.setShader(null);
            p.setColor(userTint);
            p.setAlpha(AppearancePrefs.alpha(33));
            c.drawRoundRect(rect, radius, radius, p);
        }
        p.setAlpha(255);
        // Edge: the same even line the pills and dock band had before the glass.
'@
    Change 'GlassDrawable.java' '        p.setColor(edgeColor);' @'
        p.setColor(edgeColor);
        p.setAlpha(AppearancePrefs.alpha((edgeColor >>> 24) & 0xFF));
'@
    Change 'GlassView.java' @'
    @Override
    protected void onDraw(Canvas canvas) {
'@ @'
    @Override
    protected void onDraw(Canvas canvas) {
        fill.setAlpha(AppearancePrefs.alpha(255));
        specular.setAlpha(AppearancePrefs.alpha(255));
        rim.setAlpha(AppearancePrefs.alpha(255));
        glow.setAlpha(AppearancePrefs.alpha(255));
'@
    Change 'GlassView.java' '                radius + o, radius + o, glow);' @'
                radius * AppearancePrefs.cornerScale() + o, radius * AppearancePrefs.cornerScale() + o, glow);
'@
    Change 'GlassView.java' '        canvas.drawRoundRect(rect, radius, radius, fill);' @'
        canvas.drawRoundRect(rect, radius * AppearancePrefs.cornerScale(), radius * AppearancePrefs.cornerScale(), fill);
'@
    Change 'GlassView.java' '        canvas.drawRoundRect(rect.left, rect.top, rect.right, sheenBottom, radius, radius, specular);' @'
        canvas.drawRoundRect(rect.left, rect.top, rect.right, sheenBottom,
                radius * AppearancePrefs.cornerScale(), radius * AppearancePrefs.cornerScale(), specular);
'@
    Change 'GlassView.java' '        canvas.drawRoundRect(rect, radius, radius, rim);' @'
        canvas.drawRoundRect(rect, radius * AppearancePrefs.cornerScale(), radius * AppearancePrefs.cornerScale(), rim);
'@
    Change 'DockDecoration.java' '        c.drawRoundRect(rect, radius, radius, band);' @'
        band.setAlpha(AppearancePrefs.alpha(255));
        edge.setAlpha(AppearancePrefs.alpha(255));
        c.drawRoundRect(rect, radius * AppearancePrefs.cornerScale(), radius * AppearancePrefs.cornerScale(), band);
'@
    Change 'DockDecoration.java' '        c.drawRoundRect(rect, radius, radius, edge);' @'
        c.drawRoundRect(rect, radius * AppearancePrefs.cornerScale(), radius * AppearancePrefs.cornerScale(), edge);
'@
    New-Item -ItemType Directory -Path $state -Force | Out-Null
    foreach ($name in $targets) {
        $path = Join-Path $javaRoot $name
        $backup = Join-Path $state $name
        if (-not (Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $path -Destination $backup }
    }
    foreach ($name in $targets) {
        [System.IO.File]::WriteAllText((Join-Path $javaRoot $name), $files[$name], $utf8)
    }
    Write-Host 'MainActivity, GlassDrawable, GlassView and DockDecoration upgraded.' -ForegroundColor Green
}
foreach ($class in @('AppearancePrefs.java','AppearanceSettings.java')) {
    $original = Join-Path $src $class
    if (-not (Test-Path $original)) { throw "Missing upgrade file: $class" }
    Copy-Item -LiteralPath $original -Destination (Join-Path $javaRoot $class) -Force
}
Write-Host 'Done. Your existing dock configuration, Live TV, Chromecast, Assistant and system packages remain unchanged.' -ForegroundColor Green
Write-Host 'Next: run 01_BUILD_APK.cmd in this folder, then 02_CAI_THU.cmd.'
if ($Build) {
    & (Join-Path $root '01_BUILD_APK.cmd')
}
