﻿param([ValidateSet('Apply','Verify','Restore')][string]$Action='Apply')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$javaDir=Join-Path $root 'work\CleanXiaomiTV-main\launcher\app\src\main\java\com\gathin\tvhome'
$target=Join-Path $javaDir 'AppearanceSettings.java'
$main=Join-Path $javaDir 'MainActivity.java'
$prefs=Join-Path $javaDir 'AppearancePrefs.java'
$weather=Join-Path $javaDir 'Moor2UiFix.java'
$locale=Join-Path $javaDir 'VietnameseLocale.java'
$backupDir=Join-Path $root 'state\liquid_menu_v4'
$backup=Join-Path $backupDir 'AppearanceSettings.before-v4.java'
$stamp=Join-Path $backupDir 'installed.sha256'
$expectedSha='5ADD51F2C637600BF9B3714A011A2252C12653B260988F0C2D114FE083AA4557'
function Fail([string]$message) { throw $message }
function Sha([string]$p) { return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToUpperInvariant() }
if ($Action -eq 'Restore') {
  if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { Fail "Original source backup not found: $backup" }
  Copy-Item -LiteralPath $backup -Destination $target -Force
  Write-Host 'Previous appearance menu Java file restored.' -ForegroundColor Green
  Write-Host 'Rebuild APK separately. No installed apps or settings were changed.'
  exit 0
}
foreach($item in @($main,$target,$prefs,$weather,$locale)) {
  if (-not (Test-Path -LiteralPath $item -PathType Leaf)) {
     Fail "Missing prerequisite: $item. Apply Vietnamese v2 and UI v3 first; no changes made."
  }
}
$mainText=[IO.File]::ReadAllText($main,[Text.Encoding]::UTF8)
if (-not $mainText.Contains('AppearanceSettings.show(')) { Fail 'MainActivity does not call AppearanceSettings.show. Do not patch incompatible source.' }
$prefsText=[IO.File]::ReadAllText($prefs,[Text.Encoding]::UTF8)
if (-not $prefsText.Contains('static boolean import') -and -not $prefsText.Contains('static int transparency(')) { Fail 'AppearancePrefs interface is not recognized.' }
$weatherText=[IO.File]::ReadAllText($weather,[Text.Encoding]::UTF8)
foreach ($check in @('static boolean weatherEnabled(', 'static int weatherCity(', 'static boolean ambientEnabled(', 'static void reset(')) {
  if (-not $weatherText.Contains($check)) { Fail "UI v3 API missing: $check" }
}
$localeText=[IO.File]::ReadAllText($locale,[Text.Encoding]::UTF8)
foreach ($check in @('static boolean isVietnamese(', 'static void setLanguage(')) {
  if (-not $localeText.Contains($check)) { Fail "Vietnamese v2 API missing: $check" }
}
if ($Action -eq 'Verify') {
  if ((Sha $target) -ne $expectedSha) { Fail 'Menu v4 is not installed or was modified; no changes made.' }
  Write-Host 'PASS: Liquid Glass menu v4 installed, source SHA-256 verified.' -ForegroundColor Green
  exit 0
}
$compressed='H4sIAAAAAAAC/708/W8bx5W/+6+YEGhAuvRakiVZjuvm+CmxpkhVouy0QWAslyNy6+Uuu7uUzKYGEhSX4q4NkFz6wwV3B9RNg7v2mmuK9BBU+qFAafT/oP+Se+/N7PcsRcu9CoZJ7r558+Z9vzezO9GNx/qQM8MZa0PdH5m25p+OnDG/e+2aOZ44rs90e+A65kDTJxOtYvjmqenP7qpu1k3dcoaZW4Zj+9z2w7Edx286U3vQeGLwiW86du6IFn1kbg9dfTIyDU+rmv5Yn1x2v6kbvuPO8sFqjuW4+bcHrn6m9y2u7br6wASC6vJCZojNfe3YNTPXT01+hqOVnKObD+C//Du7rjOdqG8/NO2Bc7bs3r5ug4Cz6zszB0Ogt23aXHfb+syZ+nkwR4brWJaSxgCC88dVPXeSHn/iLxvec3Qvmv0H+qmumY7WNGM8jl/sTv3J1D/yXa6PMwAtO3bv2s3r11mb63aZuXzs+PzGiel6PmubP5yaA7Zr6Z7HPO77pj302InjMn/E2Vum7oxNVhFEst4DZulT2xhxV2PXb147MW3dYgaNrUwmwD7dNvhRgOXdawz+PF/3TYMJWNP2WWu/stt4dNj47nHjqMfusdtr6xt3CXTimqe6z7NDmrsAR9qpPdxr9RqXgO8f9xp1GLH2pNmsVmrV+p1LBhxUOo02DWg01zc31jcum6HVqdR6rQcNGrO1dWtnc3tr+5IxsRHV6sYdGNG8ZES1e1hvHNKInZ16pXGnuQWSjA/Jcr1YYu+yp9dUiPuOY4EGsFOzGLggpiO4y/2pazNQTN/Wx9zjbcfQwc5NL7pU1Et3Aa8CLagYTMx8N4a1HFw9DRGEl7g9tExvVJL6gX+SACAM6HkzNoi9EYALVikJQFYNJonZTyxH99mpbk25Yp598O+ai663SCDsOtM1ML9D7jlT1+DARPxZN72Jpc/2OdBt4LUBtz2YoLSElrRrZDQNHxSRSAM1uEz0ItjUE9/7jjvg8rrnu87jBM1ZjNybWj5ohc3PMneLkjixWgTUwKqPRvqEF9Ow2mGj1qt0dtsN5SCytyLRnHPftbl7SAspivXE4MwTVhSLYd9ma6U4MXRV3izL1SdmICGJAUtYHfhS5sMXpe6hbCVbzR/Jb1IGgS30HWsQ53aEVDI4uID6H0LROvCO0B/VHTX3wttHQFARqUrfbELIb3IdWBCZdOExd+1CGrJlG9Z0wHHAgT4YAGTRdxPEoAzEAsW8swk/0Q0w5XRkD+5o9UazctzulVk+SLXbrsfm4BZY6Uuizwo7lHNC0CAv7uJAhtJ1bHBVpxiH3KldJG+kUgsRjiigHeg2t2LCFZ410pQwh0sCiPSNDWQWl7wZTxOYzM/SMFGawDz6mgZARYSI74+iGwRNMbnpGFNP+nlyAOFSVErOZ7zvOmfhb9/0rcjXDjgQYFJyGddy/AtWD3qu303cEQuX+i+YkdD+CEZz+Q+n3PNFgiXVtih+ac1GpXd82HjU6T7qtXoJJ0PKiWZpuJzbD5ETSMYqPpjYdmA+Ab3Lw7fHzeHIXxXhiKBVGM8kXRQuxqZdhCADjN9ZWyuVE6TfYOLO1kZJsciR45o/AkUBud+TgBubpZiA8S+hVq7jBO4nfj0jBIRDy+u66NZ1lHIxPkB70DjstWqVds64wG1EFJYDAjdgidnL65uqBRoUCMLFre+wb8YSkwOXn3iagPEwvt9kOzn0VKEGG4q4HIRNyszKcoqyzIhCckqlHEw1y5zURqY1cLldPNHBRy0B7DkBIwLIBGgYEqSp0fd7IuoAEaEBrm+URca5U7/dqJVZyhmTs4ww4ORtcPDcPZroBk6+pq3dOVGRCcRRBIqNLmeUQxMfB8D0sVe8sV5mNzLaGK5kxHVcb2wV0m1s3C5Dsq2kPXeyAFt7otBZJVlJxOFwzXcm+7o7NO1Ql7aX8UMOLEcYcteLahotNuYVUafLomCArFGhKEuWDUivvGYaq1jwbTVg3/F9Z5yCXd9Yyh0YWZbj0yotopIkPYpWGQcj4CgtMQUIVphKg4pAH3AX4rBuCbxQDDdszDYHlwxTW2I+7FLzloF5FSca9Fiu4EdjQwO6hWRulQIXtRl+i66tZwwzhmjVpb0UywKdkGPLKbmv4jsSuiXQruKE1shL53nUE0BKkSN0Qy78n4DFv8KLDz5+8cEnkIswYzSdLS5+YtP17n1WGy0uPhS/Xnzw0YsP/oU9/8hcXLw/BcjFxT/ZI7pVrdTus+9O9RmzFufPzEL+FB391BxiNinxH3GLG34cf2Xwg6nnR2gPKYMtlKIAcKdR3axtqt2JWDEKT7bBivJTqzU6vcbhyt5HILqq/wlGKzzQcq8iBpZDBOq0kKpDUjUahBjyATFJAPfQtXvO1Bh1p75nDnhREYGiMV37aOSctU0PpuBu0RzajssH7Ma3UzluUARFeTV7Dfg1taxSLNcOslj6UUxN+jT1WyS3DDMASQ8kleJieijOfBZNmCXtLJn0BHV5kLGGhdShRnWk5kNC5U108AxpdgpsIKSmpUPBmGh4JtRBa7Yru4/qrf1H1cZeq1NX4MkfzFDbznDBFR/S5/7U5xl+UUWmDcxxZQxrQg+8pm1unNxVLz6GJ61KT69F38KvVP55nKrBYrziSbM3UccL7yLrnTDXCc0Ve4QNZc7jK7O07ZOVrdS6on1aWcsMyV/fygIr8oMQ/nYW3OInfg7ytZxwEzgACB5WXFRp4UCCGgjGNDC/Utal3nQ81l2YTxb2uqEqURNFkQU/lPFc0p5eJcAsjel73cPW97udXiaqByPVDvpRTi4QjIonAnGRlVN8vpW5sqmAyZlk37TN8XQsCt3kVNs7eYMU1VXQxk5PvFNC07h1a+vOdnNnPX23lDcDOVDqQipsKQCCpMV4fCmQ0Lp6lKgXSYGgsixorAAfUoPyJ1meRcUBV63/vNm471hZfyL0HOuInNJJDFw56EfgCpHhdsNmfbu2s5EWy4YU2ubmVvP21mpCCxM6mvKyhC6BcXMjra9wpbS0r0Ei9F7CiMWAq6Tm+S4ZhVdxuX6pY15Dv4ycS9Ekxy9zopvLeC0WVQ4R5RWtfXOYH7t2cpVN8iyYDbC8YrPAG+uWQutDF45xdEkBTcPJaelPkAavuLGyrGjsVXNcOTg/kG4s5xyNLwdo8rijuxDxstwpvHjvvABTbIsco7ZdrzeqagYRhpWdQ0KVaOhLWe2ttVWsNgyeNrn02ki3hzxMt4un1IE6wVt8UFKn3UuijhzI3gy2RN8I91OzhRkl/pngFKFA7uLGaLMJaGIx63JEEY4NGJp1kJe64iQR24079WqViAg99AqrIa8N/1Szg+0mt5OauyoaAwOL4FLs2WquNStAGVmpAkOogSoMzV1aU6DDiuE3b7I6t8w+d6FwtmbMdphn6BbmeXiOAIsWizz3G3jLgIg7Acz1GxN9IIRAWzdcW1p3RSpJCUSojKiLpIFBOTYwvbHpYV0is0ot2C76e2TtL5OIp1NrXGIqu1YUsPeyBSxMhGPzk3LPgpLaLSZTceyJjvUn4gsklL6JjX6RkD80/VELW/ugWn3Q/KWZOZrF5CWiOsFfJaiHA9VJdjaB3l4hyd4u5c3yEgnzbcq9IPPa2a7drl6ae4XRQxw/yGaUQhqY7X6jgE47N9oTgpWDh1haoG9yf/wqyYE85gSlOH8ctJHFpTyhI6TMAoqgdTl3D1xn6HKwXsmBHLClhUYaVw9b4OAuiulTdXBTHHk7QveDIBqxpHtSpH2ctfp2M+OXA+y90XTcvwpq8OGr5z+rOaKEtm3tlJZKHRcAWc0kZ11dWwoyFfRjItbyYFQ9rn/onnLXBffDJtM+eG7hkBw7kI5AMSgGGtXX5UmYiQSIzmqcuM742OOuapqELdDJjGC8MCJF2Hq6Mq0gRNfvueAOwOlQlzJOrjhwtTouZ/ISqFYPWsOrRq3hJWEr0xBOxy3SrzLiSXeZ4xEKFSzdWD4rFrr3C6LtH6XO8/cnbLC4+Nwewq1CZTKxZoVSNpdKDmr/9cspNQYoukHS33bOuFvTPV4E31w40k953m0F7iJltUH0Q50iu8HWZ+iiEl49E3FH2A9OKWrQwB5le8V/y7ay6iSEZNSrHYgIkIP/DjGLwxHg1JOl1Q7WGeHBiQQ1NzL+Sp0nx07pJcZfZ2vazs6JMl8X2+oi+6DjG+WI2DzwlSJnvBu9wkmlIH96N+hY+3QAUJ4WC0bLE0uRwmSOJpXZ4dS25bG/E1C7xLHJ2CGnCf0vzwRGB4ZCPInFFPa73cMNSNwZO2gcHnU7lXbr+5Veq9tJ7YwlTWzX1B3QzsXFT+3EuWG00sQ5Yj08/JG22yTC3vxPs3CfzncXF38wwD4X53+esP7i/A+QqoqzyhqrzZ8ZzAIAneA/tNnzj//65eLiM7iKhu+789/arPdAU23t1aYeODfzR5ydgVgYKIcbIv4e/pgAb7nLgV6g3eXMA2eBvpr5I9MjrHFdI1ZrwSZEckWL81919lhncfFeB7nysNJuH1SAxwkEIg1/+x3WxwbPu4XeiDtsGGPucHHxsVEQ6IAzVVN4wucfcRs/39Lh4vOP578dF4iJX4yjX2KEawI7hoWnsaOAmMxPXVdsiqdP5/TDTHffGXBVCicWTR67upvx2GJWe3HxPhH4EPzmRJ9wd7n4n3+k4xG1+Z/s4RsMx9UEgfCjBJ66P3w7dC5rMWfSH2oWt4d07grimVxVqfROci7hwqOVebGpA1uK9z2WibW2tzj/dY+1W4uLD47Z/fmHnT2kd7ddOTpi+xVwF61KW6EkxK9vZNj1/KPFxadwzaGdEBC2T4IMd/eMTLxLC8yPwUbiolSH/eVrEehyYioYEBThaE+PR1P4+Xj+hT0KAq0Jeu+DMorHAabk0rw0MYKzsqaMtSZffo3szlbWXldba5mdIhVpYMz+VPAAXkrIXSGoWjsjqf35L6cRh4R3o73YjGaDgXX0MY8NzqwDQCL6gRrBx8Tly0g8zNGlPshs/hX5DHEsWx4wv0yPwmN5K6hQb4R+p+4Yj9np/Jdp7aHrUAZJ3SGaX0VzlqyIra+tXa42maXla0wtBZpRlpWcxP78vQ7bm/8cAkBtL3ARe939BjuqHTYanTz/8DAj0z2Tjrj4EOl+Rv//hyniItnQQw6eEPghHhlKs3jfcdyNY7NpPtHOBGBw/CqS8ZtKRwwh9wuaoGuD/31DCeMvzn8vYE5O1MKVkx5BqIXaZlW9/suXSsX+mQ6RDZkxzmeD5RjUQUqTIwmp4YN2ScPMsgiBFKapunvZSppvKcX50ylbXPwGODhGj+JjxEeLiSxn3MdemNq5xAiWcFeSacZk0jLuoXSB48BwzKiegbnPn43ZE7T7m2j0Ig8B2WOQgKzpFEnuYwvrJptxy4IKBt2ZWjMk6cs0YyU76+zOf9Fhnd3Fxf+wB/P32P29+S9a7GBvcfHrGqWilc7ucWW3wV5nh42jRi/P7h60MpLqDOd/tJkN+dfvYUVt4OBUH3JCKr/D5RhQeqH4AFNMIoUeaiuI4QFqgF8Ahhca4nGmQqBjlkS8soK9+OA8Q/f90fyPJpuAiXxuxDNJpBzKPe6vnJIjJiD4yfwrXbj6kT6TmhuV5HUHEmXb8dmAWxyqH3xUkIAdF0LADCfLcf0uErPKUuM1svo5j7CZLQNv/NmIqNaKVUth2n1q4gBP5N4u6Dw5tos/MHuEeXOYYvef/0Ssl1Jse7Q4f0a29BYaxePR/CsznmGH6Lkdoe/gExG6xc5Gpk961IISEQ0Gvx85J3isxdIpyh2NncczNnT1WRyrfD6mGD0aJ5C/EUxTUifJt8qSAaV3ljxCJXmYdpVpVhqkzwpOwg1TrnRvCqpOEQ9yAyiAPjVFyUK/zv9XMvJAY2Cnn7DaaP4F2zcxdcgoIzmii/9mxuL88ykbzX8nEoym64yx9XRiDrUnY6tQynJJkKNmiLiXrBzI2S/jj+jZ0fkTT/XwTe7DNuqORqKDHvJw5JgGl48CenTclA/S+zDZ81Er1P7leKHfbn33uFVnVLIUwnME8eeDllW4oga6+HmH7S8u/rXHevNPv8fEFcrQ9rrdowardFj3gNoIcYPGh4mp+2HiYcC78PGtYNFSHHDtm99Md7KiJ6VMe8CfwFgztQchT5nZAxMyAAePEZu4OxbwEB3wi3//hLwuKyTHRv40HF4OiHrbfKecwSSZIKKqt7j4IuYOZdlqzcIBlD/BpHmNRbkxKdpCsLhkJ3GZJ8xT0nidG1fUZe2jUAVt6a8CJ0O9/uBmUiqxloTwmZgtfCr40MH6Hy5c1qVIIpQnuBfnn2ETCA2/94CNnMX51wY7PqpSvMEWgYQAHJ+BpOa/CXtElToB5XRRIr6CSJYtrDL1nTExlBY3GTm+g3ir4J8pT9s3BzY1IAP/HV6YTN2JxbMLcxyPC0S0d4ELAzWVizoO73mURc2ChXRdc0i6Dz55zGMLSHRzYAFjHTv+76YLmmqrs5utPqvtSu1+9vJ+q95p7e71lpeJB8eHB+1GdnTt+KjX3V/9evewtdvqVNqpxtTYGfAVulKl5KjQOu9JBPdy6ACN3gLh5wEFRAHYdgAG8SGaLAgAwfMJy9pdgaOQWm1A0vBnYSOBTgs1NubPIKOY/4oQSE3RxdygItSidM5sqYWpVIrMtRyLFcJx5R9/l/dh7Zt5e2e+O8u5g3/i/SPU5Q4fqhHXii35TpMa+v1H3YNG51G9Wzveb3R6ioZ7TH5yB6kGnmzouLMAUa3Sa+x2D79HqCrVzGOjCizy2eNiwRxDIn3zemHJEF3zcDMvcJFNxz2k58yLpnwyJvF2ihxETxlEDGPEirlvcmG8tISd9JYPyFAe8178uRfwYQ8wr8QE3Jh/hSXY71BVYg4S0qf5ZzPRMwUYgoQ4hK5D9sAPaqoeeMIxdRxGnGIT03gMFfQJkq4xdEiYySOuqW9aGEFgJaSLiBWUWxDebnR2e3uP2t3Obkm5mZW/wxola6vsxyZ1d4u9/nq2y0O9/dACMX7dy98ZW8r82uivX+rEeGGiookuOS4ijrjxw6kuGY5bEP9mLGM4MlvQKHk+477Gas4Eecsh4gpUtFN6FRavzszLvCvulE3eFux+RzGbTCDkaSrlJnV+ekJNzivnJbGwvfnO8sRyU+aSNBQyOTxbE7ZmIa0rLXHrqzd7I3CsCj+3MRn82VR2TmwsftgAu6PWFFsFcPMf6d6HVOhVmDft41l23TDQnfojHU87QGXsnnJxPpm22F1QhBzXr24tl6KYIE7EqZrjBBkBlu6mBLuCMGX/Nr8eSpwsk/szl1ZEqYIHd/1fefczUQElSx+FQEWaORlhqortLxNGTUC+n5nSt4pNQylmakxGzxmiZA/ovAmeC4eRLqWGgQOVQyHb0+n5wUt2FMuF3db8fdY7XFz8M2J+UGkfN1RjhCgk34nnAb/l2TJSBOImlRvBDnSO0F+27Eh2e1c18LTlvVrHW/ArHwPro+yMxfkzKh8WF5+AlAHgEyotxOmHcG9ULgg0CawQpIUB0bCwU5u2xFgp8a4goRpvtpbFtV6iYf505V49lmFreCw5OSKW6cVHg2QfphCEWSGEw7WrWHm8+f3Snvv/pzGU6QtFO+XUHXKCykm0iRItooy3f9X9BYGlFpxGSCCT+dnIYd0Jt2/sc59TLSmfJkalCtBSFItBpWYRjMzfs8iCz5ZohxgjO19X0IlkC/+q5v7qGyIx20puV4gEjSoz1kdPEO5fyOor3MQAwyd60xsZWH2JnQxx6Ei5oaEwfkHMX77GfdEZOhzSgWC7BK673HDGY47HiEPvQB6DEeUe/D8UfEi327s2jidGiD6C6K8/XXmTCJ3JOp7iL6eOfMaThaTCVFIoYqkFOJT1qyhPuNNxBb1ZsjOT3GOBm+EOS77I0hsz5Whf5mk5bIMp/G+SZZkX5tHhs2A/J8myNWxHnprUjeT4Mq+XZ6DYPLmy1eVtEr2p2iV6U21yi4v/ClWzHJ0FiBdMQQVL5of7SPJsiSfh8YwApURQrnkOemvRBcODV0EWPFjB4CBc/OeMuif0AoHQphLLHJPRk3cWKZpYJ0w34Cc61P1kR0sNQ1mVhhCvoTHkVmHpBFxufymqq5j15QOtVILRB77tsyXfMMp6D24eH1Vl/YmctlHQNwIVQ0XB03EDtr62szaBWhQ0GV/vGTuiGBzBFq8YbY2TZhxu5x27Jpu6ZlwNkVtwKarK5V4NPQkXrQHfZgr66KbOqjae+NwFHcHbXt10i4Qj+YY7GrUKdu4FvSv8jePyOpePmq1E44nG+3w8eZnx9KyyP54kXtyXabMlXs2rdYXRokyCwlcJkBY/wmum/R2oLOoQZwa8SlsBWP26U556zBFoKMZeDsvoyHec6/LpazwobJ3iuX7NgQQlNgQlWlI1WJLEDogUOcS0yySjMhGbe7w2kCqtyJn64g1r30IH+uMfs+CqPAqMl/NkHraJ9fHEwvbyeurtbiMUamqemwH4t9n6nQ3VlHEIMJdS8PP6PbaxqkwUlErgI0KGL4fEE/P0Qwl3QCdWXT6oUaYLwILzmvitHe5WH21tb91VqBrry5dF/710QswXkvi3UI4A5XKrDxeWflUyw6fWIkuO3yqilSuXgfO+JibWIJOb0DMAIdfF76bjjnVf+85BY7fMdjbLOBEg80f4jDBOFzaIiwUEYtxGJgDhQMZA1bfGRzhOrKk3yjh8sUFqgT+RHIbAYcwMegWsgmWv4cI00yPXVULFpgtiA7ZYEmXiMlNCTwseNELx+uvsNboiToEUS8uGB+/5xDmh0IakqecQPsKDbzOlyMIHFFvyTiGHjfeo0f5jBuLrnuzzMShVw3UhR8703oOns7CrrbWdoXZWFH0hLXLfMpPAUy3yPdoT08DXWcKNzMsDlcuMSwS5RWvlT0zPx2dFxNIDVt0NHyNY8p5mJVcSb26+tnpzVx2oFG9iDePF02tPr/0fZ0aMxhZfAAA='
$bytes=[Convert]::FromBase64String($compressed)
$inStream=[IO.MemoryStream]::new([byte[]]$bytes)
$zipStream=[IO.Compression.GZipStream]::new($inStream,[IO.Compression.CompressionMode]::Decompress)
$outStream=[IO.MemoryStream]::new()
try {
   $zipStream.CopyTo($outStream)
   $content=[Text.Encoding]::UTF8.GetString($outStream.ToArray())
} finally { $zipStream.Dispose(); $inStream.Dispose(); $outStream.Dispose() }
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
if ((Sha $target) -eq $expectedSha) {
   Write-Host 'Menu v4 is already installed. No changes made.' -ForegroundColor Green
   exit 0
}
if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) {
   Copy-Item -LiteralPath $target -Destination $backup
   Write-Host "Saved rollback source: $backup"
}
$temp=Join-Path $backupDir 'AppearanceSettings.stage.java'
[IO.File]::WriteAllText($temp,$content,[Text.UTF8Encoding]::new($false))
if ((Sha $temp) -ne $expectedSha) { Remove-Item -LiteralPath $temp -Force; Fail 'Embedded source hash mismatch, no file changed.' }
Copy-Item -LiteralPath $temp -Destination $target -Force
Remove-Item -LiteralPath $temp -Force
[IO.File]::WriteAllText($stamp, $expectedSha, [Text.Encoding]::ASCII)
Write-Host 'OK: Liquid Glass v4 menu applied.' -ForegroundColor Green
Write-Host 'Only AppearanceSettings.java changed; all TV services and saved preferences remain untouched.'
