@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0CleanXiaomiTV_MOOR2.apk" (echo [ERROR] Build APK first. & pause & exit /b 1)
where adb >nul 2>nul
if errorlevel 1 (echo [ERROR] adb.exe not in PATH. & pause & exit /b 1)
adb devices
set /p APPROVE=Install APK to the connected Android TV? Type INSTALL: 
if /i not "%APPROVE%"=="INSTALL" exit /b 0
adb install -r "%~dp0CleanXiaomiTV_MOOR2.apk"
if errorlevel 1 (
 echo [ERROR] Installation failed. For INSTALL_FAILED_UPDATE_INCOMPATIBLE, stop and inspect signing keys.
 echo [CAUTION] Do not uninstall the active Home launcher before restoring another working Home.
 pause
 exit /b 1
)
echo [OK] APK installed. Home selection and system packages were not changed.
pause
