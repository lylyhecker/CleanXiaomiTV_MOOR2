@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LIQUID_MENU_V4.ps1" -Action Restore
if errorlevel 1 (echo [ERROR] Restore failed. & pause & exit /b 1)
echo [OK] Old source restored. Rebuild APK to revert menu visuals.
pause
