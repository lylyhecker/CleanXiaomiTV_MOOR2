# CleanXiaomiTV — Liquid Glass Menu v4 (MiTV-MOOR2)

## Có gì mới

Menu cài đặt mới được thiết kế giống thanh Dock và các nút kính trên màn hình Home: nền kính xanh than trung tính, đường viền mảnh, góc bo tròn, mô tả từng tùy chọn, phân nhóm, menu phụ đồng bộ. Tất cả các hàng có focus rõ khi điều khiển bằng D-pad, không phóng to nên không bị cắt ở rìa.

Các mục hiện có được giữ nguyên: ảnh nền Bing/màu nền/ảnh từ USB hoặc ADB, độ trong suốt kính, màu kính, bo góc, bật/tắt và chọn thành phố thời tiết, hiệu ứng ám màu theo Dock, Tiếng Việt / English và khôi phục thiết lập giao diện.

Bản v4 thay **duy nhất** `AppearanceSettings.java`; không xóa dữ liệu, không thay Home mặc định, không tắt ứng dụng hệ thống, không can thiệp LAN hay firmware. Mã nguồn dùng UTF-8 với phông chữ hệ thống, hỗ trợ tiếng Việt.

## Điều kiện

Trên Windows, bạn đã có thư mục `android_tv_preflight\work\CleanXiaomiTV-main` và đã áp dụng các bản nâng cấp Appearance, Vietnamese v2 và UI v3 trước đó. Nếu thiếu `VietnameseLocale.java` hoặc `Moor2UiFix.java`, bản vá sẽ báo lỗi và không thay đổi mã nguồn. Vẫn dùng JDK và Android SDK đã cài.

## Cách dùng

1. Giải nén **toàn bộ** ZIP vào `C:\Users\bahoa\Downloads\android_tv_preflight` (thư mục đang có `01_BUILD_APK.cmd`).
2. Chạy `01_AP_DUNG_MENU_V4.cmd`.
3. Chạy `05_KIEM_TRA_MENU.cmd` để kiểm tra SHA-256.
4. Chạy `02_BUILD_MENU_V4.cmd` để dùng Gradle build APK.
5. Khi build thành công và chắc chắn đã có Home dự phòng, chạy `03_CAI_DE_MENU_V4.cmd` để cập nhật qua ADB. Đây **không** phải APK sẵn.

`INSTALL_FAILED_UPDATE_INCOMPATIBLE` có nghĩa khóa ký APK không khớp. **Không gỡ ứng dụng đang làm Home** khi chưa xác nhận Google TV Launcher hoạt động. Bản vá không giải quyết vấn đề khóa ký.

## Sao lưu và phục hồi

Bản gốc được sao lưu tại `state\liquid_menu_v4\AppearanceSettings.before-v4.java` (ngoài thư mục `res`). Chạy `04_KHOI_PHUC_MENU.cmd` để hoàn nguyên mã Java, rồi build lại APK nếu muốn trở lại menu cũ.

## Trạng thái thử nghiệm

Đã kiểm tra cấu trúc ZIP, nội dung UTF-8, chữ ký phương thức Java dự kiến và SHA-256 tệp. **Chưa build được APK hoàn chỉnh hoặc chạy thử giao diện trên MiTV-MOOR2 thực tế** ở môi trường này.

Nguồn dự án: https://github.com/majnioui/CleanXiaomiTV (MIT). Bản nâng cấp là phần mã nguồn chỉnh sửa, không phân phối APK hoặc chữ ký số của tác giả.
