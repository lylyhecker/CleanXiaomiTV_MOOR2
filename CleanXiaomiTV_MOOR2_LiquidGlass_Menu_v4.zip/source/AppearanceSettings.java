package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Lean, remote-first Liquid Glass settings for the Xiaomi Android TV launcher. */
final class AppearanceSettings {
    static final int IMAGE_REQUEST = 7012;
    private static final int FG = Color.WHITE;
    private static final int MUTED = 0xFFBACBD9;
    private static final int PANEL = 0xEF14212E;
    private static final int INACTIVE = 0x55384656;
    private static final int ACTIVE = 0xBB29465F;
    private static final int BORDER = 0x88DAE9F5;

    private AppearanceSettings() { }

    private static boolean vi(Activity a) { return VietnameseLocale.isVietnamese(a); }
    private static String tr(Activity a, String vietnamese, String english) {
        return vi(a) ? vietnamese : english;
    }
    private static int dp(Activity a, float value) {
        return Math.round(value * a.getResources().getDisplayMetrics().density);
    }
    private static GradientDrawable rounded(int color, int radius, int border, int stroke) {
        GradientDrawable result = new GradientDrawable();
        result.setShape(GradientDrawable.RECTANGLE);
        result.setColor(color);
        result.setCornerRadius(radius);
        if (stroke > 0) result.setStroke(stroke, border);
        return result;
    }
    private static TextView text(Activity a, String value, int size, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setFontFeatureSettings("kern");
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        else t.setTypeface(android.graphics.Typeface.DEFAULT);
        return t;
    }

    private interface Action { void run(); }

    private static class GlassPanel {
        final Activity activity;
        final Dialog dialog;
        final LinearLayout content;
        final ScrollView scroll;
        final int width;
        View firstFocus;

        GlassPanel(Activity a, String eyebrow, String title, String description) {
            activity = a;
            dialog = new Dialog(a);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            int screenWidth = a.getResources().getDisplayMetrics().widthPixels;
            int screenHeight = a.getResources().getDisplayMetrics().heightPixels;
            width = Math.min(dp(a, 800), screenWidth - dp(a, 52));
            int horizontal = dp(a, 24);

            LinearLayout root = new LinearLayout(a);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(horizontal, dp(a, 22), horizontal, dp(a, 14));
            int corner = dp(a, 18 + AppearancePrefs.corners(a) / 8);
            root.setBackground(rounded(PANEL, corner, BORDER, dp(a, 1)));
            root.setClipChildren(false);
            root.setClipToPadding(false);

            TextView eyebrowView = text(a, eyebrow, 12, 0xFFB8D7EC, true);
            eyebrowView.setLetterSpacing(0.09f);
            root.addView(eyebrowView, new LinearLayout.LayoutParams(-1, -2));
            TextView heading = text(a, title, 27, FG, true);
            LinearLayout.LayoutParams headingLp = new LinearLayout.LayoutParams(-1, -2);
            headingLp.topMargin = dp(a, 6);
            root.addView(heading, headingLp);
            TextView hint = text(a, description, 14, MUTED, false);
            LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
            hintLp.topMargin = dp(a, 7);
            hintLp.bottomMargin = dp(a, 12);
            root.addView(hint, hintLp);

            scroll = new ScrollView(a);
            scroll.setFillViewport(false);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.setClipToPadding(false);
            scroll.setClipChildren(false);
            content = new LinearLayout(a);
            content.setOrientation(LinearLayout.VERTICAL);
            content.setPadding(dp(a, 3), dp(a, 4), dp(a, 3), dp(a, 12));
            content.setClipChildren(false);
            content.setClipToPadding(false);
            scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
            root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

            TextView footer = text(a, tr(a,
                "↑↓ Di chuyển     OK Chọn     ←→ Điều chỉnh     BACK Quay lại",
                "↑↓ Navigate     OK Select     ←→ Adjust     BACK Return"), 12, 0xFF9EB4C4, false);
            footer.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
            footerLp.topMargin = dp(a, 12);
            root.addView(footer, footerLp);
            dialog.setContentView(root);
            dialog.setCanceledOnTouchOutside(true);
            dialog.setOnShowListener(ignored -> {
                if (firstFocus != null) firstFocus.requestFocus();
            });
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawableResource(android.R.color.transparent);
                w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                WindowManager.LayoutParams p = w.getAttributes();
                p.dimAmount = 0.42f;
                w.setAttributes(p);
            }
        }

        void section(String title) {
            TextView t = text(activity, title, 12, 0xFF9FBACE, true);
            t.setLetterSpacing(0.06f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(activity, 15);
            lp.bottomMargin = dp(activity, 7);
            lp.leftMargin = dp(activity, 10);
            content.addView(t, lp);
        }

        void row(String icon, String title, String summary, Action action) {
            LinearLayout line = new LinearLayout(activity);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(activity, 15), dp(activity, 13), dp(activity, 14), dp(activity, 13));
            line.setMinimumHeight(dp(activity, 68));
            line.setBackground(rounded(INACTIVE, dp(activity, 18), 0x33596F81, dp(activity, 1)));
            line.setFocusable(true);
            line.setClickable(true);
            line.setContentDescription(title + ". " + summary);
            line.setClipChildren(false);
            line.setClipToPadding(false);

            TextView symbol = text(activity, icon, 14, FG, true);
            symbol.setGravity(Gravity.CENTER);
            symbol.setBackground(rounded(0x554D6C82, dp(activity, 12), 0x33445F75, dp(activity, 1)));
            line.addView(symbol, new LinearLayout.LayoutParams(dp(activity, 42), dp(activity, 42)));

            LinearLayout titles = new LinearLayout(activity);
            titles.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams textArea = new LinearLayout.LayoutParams(0, -2, 1);
            textArea.leftMargin = dp(activity, 14);
            line.addView(titles, textArea);
            TextView big = text(activity, title, 18, FG, true);
            titles.addView(big, new LinearLayout.LayoutParams(-1, -2));
            TextView small = text(activity, summary, 12, MUTED, false);
            small.setMaxLines(2);
            LinearLayout.LayoutParams smallLp = new LinearLayout.LayoutParams(-1, -2);
            smallLp.topMargin = dp(activity, 2);
            titles.addView(small, smallLp);
            TextView arrow = text(activity, "›", 26, 0xFFC6DDEB, false);
            arrow.setGravity(Gravity.CENTER);
            line.addView(arrow, new LinearLayout.LayoutParams(dp(activity, 30), dp(activity, 42)));

            line.setOnFocusChangeListener((view, focused) -> {
                line.setBackground(rounded(focused ? ACTIVE : INACTIVE,
                    dp(activity, 18), focused ? 0xFFE9F5FF : 0x33596F81,
                    dp(activity, focused ? 2 : 1)));
                symbol.setBackground(rounded(focused ? 0xFF6E9DBB : 0x554D6C82,
                    dp(activity, 12), 0, 0));
                big.setTextColor(FG);
                small.setTextColor(focused ? 0xFFE5F0FA : MUTED);
                arrow.setTextColor(focused ? FG : 0xFFC6DDEB);
                // Deliberately no scaling or translation: no clipped D-pad focus state.
            });
            line.setOnClickListener(view -> { dialog.dismiss(); action.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(activity, 7);
            content.addView(line, lp);
            if (firstFocus == null) firstFocus = line;
        }

        void slider(String title, int max, int initial, ActionWithInt callback) {
            LinearLayout group = new LinearLayout(activity);
            group.setOrientation(LinearLayout.VERTICAL);
            group.setPadding(dp(activity, 14), dp(activity, 16), dp(activity, 14), dp(activity, 16));
            group.setBackground(rounded(INACTIVE, dp(activity, 17), 0x44586C7B, dp(activity, 1)));
            TextView value = text(activity, initial + "%", 30, FG, true);
            value.setGravity(Gravity.CENTER);
            group.addView(value, new LinearLayout.LayoutParams(-1, -2));
            SeekBar seek = new SeekBar(activity);
            seek.setMax(max);
            seek.setProgress(initial);
            seek.setFocusable(true);
            seek.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFB0D6F0));
            seek.setThumbTintList(android.content.res.ColorStateList.valueOf(FG));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(activity, 58));
            group.addView(seek, sp);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                    value.setText(progress + "%");
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });
            LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, -2);
            glp.bottomMargin = dp(activity, 12);
            content.addView(group, glp);
            firstFocus = seek;
            row("OK", tr(activity, "Áp dụng", "Apply"),
                tr(activity, "Lưu " + title.toLowerCase(), "Save " + title.toLowerCase()),
                () -> callback.set(seek.getProgress()));
        }

        void show() {
            dialog.show();
            Window w = dialog.getWindow();
            if (w != null) {
                int screenHeight = activity.getResources().getDisplayMetrics().heightPixels;
                int maxHeight = Math.max(dp(activity, 280), Math.min(screenHeight - dp(activity, 58),
                    Math.round(screenHeight * 0.88f)));
                w.setLayout(width, maxHeight);
                w.setGravity(Gravity.CENTER);
            }
        }
    }

    private interface ActionWithInt { void set(int value); }

    static void show(Activity activity, Runnable refresh) {
        GlassPanel panel = new GlassPanel(activity,
            "MOOR2  /  PERSONALIZATION",
            tr(activity, "Giao diện Liquid Glass", "Liquid Glass appearance"),
            tr(activity, "Tùy chỉnh trực tiếp bằng remote. Các lựa chọn được lưu trên TV.",
                "Customize with your remote. Your preferences are saved on this TV."));
        panel.section(tr(activity, "ẢNH NỀN", "WALLPAPER"));
        String[] bg = {"Theo giao diện gốc", "Ảnh Bing", "Đen", "Xanh đêm", "Tím đêm", "Ảnh riêng"};
        int current = AppearancePrefs.backgroundMode(activity);
        panel.row("BG", tr(activity, "Ảnh nền", "Wallpaper"),
            tr(activity, "Đang dùng: ", "Current: ") + bg[Math.max(0, Math.min(bg.length - 1, current))],
            () -> backgrounds(activity, refresh));

        panel.section(tr(activity, "CHẤT LIỆU KÍNH", "GLASS MATERIAL"));
        panel.row("%", tr(activity, "Độ trong suốt", "Transparency"),
            AppearancePrefs.transparency(activity) + "% · " + tr(activity, "Áp dụng cho các khung kính", "Applied to glass surfaces"),
            () -> slider(activity, tr(activity, "Độ trong suốt", "Transparency"), 95,
                AppearancePrefs.transparency(activity), v -> AppearancePrefs.setTransparency(activity, v), refresh));
        panel.row("CL", tr(activity, "Màu kính", "Glass color"),
            tintName(activity, AppearancePrefs.tint(activity)), () -> tint(activity, refresh));
        panel.row("R", tr(activity, "Độ bo góc", "Corner radius"),
            AppearancePrefs.corners(activity) + "% · " + tr(activity, "Thanh Dock và khung kính", "Dock and glass panels"),
            () -> slider(activity, tr(activity, "Độ bo góc", "Corner radius"), 100,
                AppearancePrefs.corners(activity), v -> AppearancePrefs.setCorners(activity, v), refresh));

        panel.section(tr(activity, "MÀN HÌNH CHÍNH", "HOME SCREEN"));
        panel.row("W", tr(activity, "Hiển thị thời tiết", "Weather widget"),
            Moor2UiFix.weatherEnabled(activity) ? tr(activity, "Đang bật", "On") : tr(activity, "Đang tắt", "Off"),
            () -> weatherSwitch(activity, refresh));
        panel.row("°", tr(activity, "Địa điểm thời tiết", "Weather location"),
            weatherCityName(activity, Moor2UiFix.weatherCity(activity)), () -> weatherCity(activity, refresh));
        panel.row("FX", tr(activity, "Hiệu ứng màu theo Dock", "Dock ambient color"),
            Moor2UiFix.ambientEnabled(activity) ? tr(activity, "Đang bật", "On")
                : tr(activity, "Tắt để tránh ám xanh / vàng", "Off to prevent blue / yellow tint"),
            () -> ambientSwitch(activity, refresh));

        panel.section(tr(activity, "NGÔN NGỮ VÀ KHÔI PHỤC", "LANGUAGE & RESET"));
        panel.row("VI", tr(activity, "Ngôn ngữ / Language", "Language / Ngôn ngữ"),
            vi(activity) ? "Tiếng Việt" : "English", () -> language(activity, refresh));
        panel.row("↺", tr(activity, "Khôi phục giao diện", "Reset appearance"),
            tr(activity, "Không xóa Dock hay ứng dụng", "Does not delete the Dock or any apps"),
            () -> reset(activity, refresh));
        panel.show();
    }

    private static String tintName(Activity a, int value) {
        String[] viNames = {"Trắng tự nhiên", "Xanh băng", "Tím nhạt", "Xám khói"};
        String[] enNames = {"Natural white", "Ice blue", "Soft lilac", "Smoky gray"};
        return (vi(a) ? viNames : enNames)[Math.max(0, Math.min(3, value))];
    }
    private static String weatherCityName(Activity a, int city) {
        String[] cities = {"Huế", "Hà Nội", "Đà Nẵng", "TP. Hồ Chí Minh",
            tr(a, "Từ cấu hình", "From config.xml")};
        return cities[Math.max(0, Math.min(cities.length - 1, city))];
    }
    private static void options(Activity a, String title, String description,
                                String[] choices, int selected, ActionWithInt action) {
        GlassPanel panel = new GlassPanel(a, "MOOR2  /  LIQUID GLASS", title, description);
        panel.section(tr(a, "CHỌN MỘT TÙY CHỌN", "CHOOSE AN OPTION"));
        for (int i = 0; i < choices.length; i++) {
            final int index = i;
            String indicator = i == selected ? "✓" : " ";
            panel.row(indicator, choices[i], i == selected ? tr(a, "Đang sử dụng", "Currently selected") : " ",
                () -> action.set(index));
        }
        panel.show();
    }
    private static void backgrounds(Activity a, Runnable refresh) {
        String[] names = vi(a) ? new String[] {
            "Ảnh Bing tự động", "Nền đen", "Xanh đêm", "Tím đêm",
            "Chọn ảnh từ TV hoặc USB", "Dùng ảnh đã chép bằng ADB", "Theo giao diện gốc"
        } : new String[] {
            "Automatic Bing photo", "Black", "Midnight blue", "Midnight purple",
            "Choose photo from TV or USB", "Use photo sent by ADB", "Original theme"
        };
        int[] map = {AppearancePrefs.BING, AppearancePrefs.BLACK, AppearancePrefs.MIDNIGHT,
            AppearancePrefs.PURPLE, AppearancePrefs.CUSTOM, AppearancePrefs.CUSTOM, AppearancePrefs.ORIGINAL};
        int mode = AppearancePrefs.backgroundMode(a);
        int selected = mode == AppearancePrefs.CUSTOM ? 5 : mode == AppearancePrefs.ORIGINAL ? 6 : mode - 1;
        options(a, tr(a,"Ảnh nền", "Wallpaper"), tr(a, "Chọn chế độ hoặc ảnh cá nhân", "Choose a mode or your own photo"),
            names, selected, choice -> {
                if (choice == 4) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/*");
                        a.startActivityForResult(intent, IMAGE_REQUEST);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(a, tr(a, "TV không có trình chọn ảnh. Hãy dùng công cụ ADB trên PC.",
                            "No image picker found. Use the ADB utility on your PC."), Toast.LENGTH_LONG).show();
                    }
                    return;
                }
                if (choice == 5 && AppearancePrefs.customWallpaper(a) == null) {
                    Toast.makeText(a, tr(a, "Chưa có ảnh riêng. Hãy chép ảnh qua ADB trước.",
                        "No custom image yet. Copy one via ADB first."), Toast.LENGTH_LONG).show();
                    return;
                }
                AppearancePrefs.backgroundMode(a, map[choice]);
                refresh.run();
            });
    }
    private static void tint(Activity a, Runnable refresh) {
        String[] names = new String[4];
        for (int i = 0; i < 4; i++) names[i] = tintName(a, i);
        options(a, tr(a,"Màu kính", "Glass color"),
            tr(a,"Màu nhấn dịu để nội dung luôn dễ đọc", "A subtle accent that preserves text contrast"),
            names, AppearancePrefs.tint(a), selected -> { AppearancePrefs.setTint(a, selected); refresh.run(); });
    }
    private static void slider(Activity a, String title, int max, int current,
                               ActionWithInt apply, Runnable refresh) {
        GlassPanel panel = new GlassPanel(a, "MOOR2  /  GLASS", title,
            tr(a,"Dùng phím trái / phải trên remote để điều chỉnh", "Press left / right on your remote to adjust"));
        panel.section(tr(a,"GIÁ TRỊ", "VALUE"));
        panel.slider(title, max, current, value -> { apply.set(value); refresh.run(); });
        panel.show();
    }
    private static void weatherSwitch(Activity a, Runnable refresh) {
        options(a, tr(a, "Hiển thị thời tiết", "Weather widget"),
            tr(a,"Hiển thị thời tiết bên cạnh đồng hồ", "Display current weather next to the clock"),
            new String[]{tr(a,"Bật", "On"),tr(a,"Tắt", "Off")},
            Moor2UiFix.weatherEnabled(a) ? 0 : 1,
            choice -> { Moor2UiFix.setWeatherEnabled(a, choice == 0); refresh.run(); });
    }
    private static void weatherCity(Activity a, Runnable refresh) {
        String[] cities = {"Huế", "Hà Nội", "Đà Nẵng", "TP. Hồ Chí Minh",
            tr(a,"Từ cấu hình gốc", "From original config")};
        options(a, tr(a,"Địa điểm thời tiết", "Weather location"),
            tr(a,"Chọn địa điểm dùng cho Open-Meteo", "Select the location for Open-Meteo"),
            cities, Moor2UiFix.weatherCity(a),
            city -> { Moor2UiFix.setWeatherCity(a, city); refresh.run(); });
    }
    private static void ambientSwitch(Activity a, Runnable refresh) {
        options(a, tr(a,"Hiệu ứng màu theo Dock", "Dock ambient color"),
            tr(a,"Tắt để tránh ảnh nền bị ám xanh hoặc vàng", "Disable to prevent blue or yellow screen tint"),
            new String[]{tr(a,"Tắt · khuyên dùng", "Off · recommended"),tr(a,"Bật ánh sáng theo ứng dụng", "On · color from apps")},
            Moor2UiFix.ambientEnabled(a) ? 1 : 0,
            selected -> { Moor2UiFix.setAmbientEnabled(a, selected == 1); refresh.run(); });
    }
    private static void language(Activity a, Runnable refresh) {
        options(a, "Ngôn ngữ / Language", "Tiếng Việt / English",
            new String[]{"Tiếng Việt", "English"}, vi(a) ? 0 : 1,
            selected -> { VietnameseLocale.setLanguage(a, selected == 0 ? "vi" : "en"); refresh.run(); });
    }
    private static void reset(Activity a, Runnable refresh) {
        options(a, tr(a,"Khôi phục giao diện?", "Reset appearance?"),
            tr(a,"Ứng dụng, Dock và ảnh riêng không bị xóa", "Apps, Dock and your personal photo are preserved"),
            new String[]{tr(a,"Hủy", "Cancel"),tr(a,"Khôi phục mặc định", "Reset to defaults")}, 0,
            selected -> {
                if (selected != 1) return;
                AppearancePrefs.reset(a);
                Moor2UiFix.reset(a);
                refresh.run();
            });
    }

    /** Import a TV/USB image to an app-private optimized 1080p file. */
    static boolean importImage(Activity activity, Uri uri) {
        if (uri == null) return false;
        File dir = activity.getExternalFilesDir(null);
        if (dir == null) return false;
        File dest = new File(dir, AppearancePrefs.CUSTOM_FILE);
        File temp = new File(dir, AppearancePrefs.CUSTOM_FILE + ".tmp");
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            try (InputStream in = activity.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, opts);
            }
            if (opts.outWidth <= 0 || opts.outHeight <= 0) return false;
            int sample = 1;
            while (opts.outWidth / sample > 1920 || opts.outHeight / sample > 1080) sample *= 2;
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmap;
            try (InputStream in = activity.getContentResolver().openInputStream(uri)) {
                bitmap = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bitmap == null) return false;
            try (FileOutputStream out = new FileOutputStream(temp)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 84, out)) throw new Exception("JPEG encode failed");
                out.flush();
            } finally { bitmap.recycle(); }
            if (!temp.isFile() || temp.length() == 0) return false;
            if (dest.isFile() && !dest.delete()) return false;
            return temp.renameTo(dest) && setImportedImageMode(activity);
        } catch (Exception | OutOfMemoryError e) {
            android.util.Log.w("MOOR2.Appearance", "Cannot import picture", e);
            return false;
        } finally { if (temp.exists()) temp.delete(); }
    }
    private static boolean setImportedImageMode(Activity a) {
        AppearancePrefs.backgroundMode(a, AppearancePrefs.CUSTOM);
        return true;
    }
}
