@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LIQUID_MENU_V4.ps1" -Action Verify
if errorlevel 1 (echo [ERROR] Please run 01_AP_DUNG_MENU_V4.cmd first. & pause & exit /b 1)
if not exist "%~dp001_BUILD_APK.cmd" (echo [ERROR] Original 01_BUILD_APK.cmd missing. & pause & exit /b 1)
call "%~dp001_BUILD_APK.cmd"
if errorlevel 1 (echo [ERROR] Build failed. No TV packages changed. & pause & exit /b 1)
if not exist "%~dp0CleanXiaomiTV_MOOR2.apk" (echo [ERROR] APK missing after build. & pause & exit /b 1)
echo [OK] CleanXiaomiTV_MOOR2.apk built.
pause
