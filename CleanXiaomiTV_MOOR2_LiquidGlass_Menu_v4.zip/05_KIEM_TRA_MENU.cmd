@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LIQUID_MENU_V4.ps1" -Action Verify
if errorlevel 1 (echo [ERROR] Verification failed. & pause & exit /b 1)
echo [OK] Source verified.
pause
