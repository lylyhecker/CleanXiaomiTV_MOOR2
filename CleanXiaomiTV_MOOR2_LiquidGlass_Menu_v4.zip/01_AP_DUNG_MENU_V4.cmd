@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LIQUID_MENU_V4.ps1" -Action Apply
if errorlevel 1 (echo [ERROR] Patch stopped without altering TV. & pause & exit /b 1)
echo [OK] Source ready. Run 02_BUILD_MENU_V4.cmd.
pause
